export type UserRole = 'community_head' | 'volunteer' | 'ngo';
export type IssuePriority = 'low' | 'medium' | 'high' | 'critical';
export type IssueStatus = 'reported' | 'in_progress' | 'solved';

export interface Location {
  lat: number;
  lng: number;
  address?: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  isOnboarded?: boolean;
  isVerified?: boolean; // New: Verification status
  
  // Community Head specific
  assignedRegion?: string;
  officialDesignation?: string;
  languagePreference?: 'hindi' | 'telugu' | 'tamil' | 'kannada' | 'bengali' | 'english';

  // Volunteer specific
  skills?: string[];
  mindsetStatement?: string;
  status?: 'active' | 'away';
  location?: Location;
  badges?: string[];
  impactPoints?: number;

  // NGO specific
  organizationName?: string;
  registrationNumber?: string;
  panDetails?: string;
  officeAddress?: string;
  officeBearers?: {
    name: string;
    contact: string;
    role: string;
  }[];

  createdAt: any;
  updatedAt?: any;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  originalText?: string;
  translatedText?: string;
  location: Location;
  region: string;
  priority: IssuePriority;
  status: IssueStatus;
  communityHeadId: string;
  assignedVolunteerId?: string;
  volunteerStatus?: 'pending' | 'accepted' | 'declined';
  ngoId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface Chat {
  id: string;
  issueId: string;
  memberIds: string[];
  createdAt: number;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  imageUrl?: string;
  createdAt: number;
}

export interface Escalation {
  issueId: string;
  reason: string;
  communityHeadId: string;
  createdAt: number;
}

export interface Decline {
  issueId: string;
  volunteerId: string;
  reason: string;
  createdAt: number;
}
