import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { FirebaseProvider, useFirebase } from './contexts/FirebaseContext';
import { Zap } from 'lucide-react';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import ChatRoom from './pages/ChatRoom';
import ProfilePage from './pages/ProfilePage';
import Header from './components/Header';
import SyncStatusBar from './components/SyncStatusBar';

import OnboardingPage from './pages/OnboardingPage';
import BottomNav from './components/BottomNav';

import { LanguageProvider } from './contexts/LanguageContext';

const ProtectedRoute = ({ children, requireOnboarding = true }: { children: React.ReactNode, requireOnboarding?: boolean }) => {
  const { user, profile, loading } = useFirebase();
  if (loading) return null;
  if (!user) return <Navigate to="/" />;
  
  if (requireOnboarding && profile && !profile.isOnboarded) {
    return <Navigate to="/onboarding" />;
  }
  
  return <>{children}</>;
};

function AppRoutes() {
  const { user, profile, loading } = useFirebase();
  
  if (loading) return (
    <div className="h-screen w-screen flex items-center justify-center bg-surface-container-lowest">
      <div className="text-center space-y-8">
        <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mx-auto shadow-lg shadow-primary/20">
          <Zap className="w-10 h-10 text-on-primary animate-pulse" fill="currentColor" />
        </div>
        <div className="space-y-3">
          <h2 className="text-3xl font-headline font-bold tracking-tight text-primary uppercase">Field Connect</h2>
          <div className="flex flex-col items-center gap-2">
            <div className="w-48 h-1.5 bg-surface-container-highest rounded-full overflow-hidden">
              <div className="w-1/2 h-full bg-primary animate-[move-progress_1.5s_infinite_linear]" />
            </div>
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-on-surface-variant animate-pulse">Establishing Secure Hub Connection</p>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes move-progress {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}</style>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-surface overflow-x-hidden pb-20">
      {user && <Header />}
      {user && <SyncStatusBar />}
      <div className="flex-1 flex flex-col">
        <Routes>
          <Route path="/" element={(user && profile?.isOnboarded) ? <Navigate to="/dashboard" /> : (user ? <Navigate to="/onboarding" /> : <LandingPage />)} />
          <Route path="/onboarding" element={<ProtectedRoute requireOnboarding={false}><OnboardingPage /></ProtectedRoute>} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/issues" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/report" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/reports" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/sync" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/active-tasks" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/impact" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/chats" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/triage" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/match" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/bottlenecks" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/chat/:chatId" element={<ProtectedRoute><ChatRoom /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </div>
      {user && <BottomNav />}
    </div>
  );
}

export default function App() {
  return (
    <FirebaseProvider>
      <LanguageProvider>
        <Router>
          <AppRoutes />
        </Router>
      </LanguageProvider>
    </FirebaseProvider>
  );
}
