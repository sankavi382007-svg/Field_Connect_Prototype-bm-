import React, { useState } from 'react';
import { useFirebase } from '../contexts/FirebaseContext';
import { useTranslation } from '../contexts/LanguageContext';
import { languages } from '../lib/translations';
import { Globe, ChevronDown, User as UserIcon, Zap, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function Header() {
  const { profile } = useFirebase();
  const { language, setLanguage, t } = useTranslation();
  const [isLangOpen, setIsLangOpen] = useState(false);

  const currentLang = languages.find(l => l.code === language);

  return (
    <header className="bg-surface-container-lowest border-b border-outline-variant h-16 flex items-center justify-between px-6 sticky top-0 z-50">
      <div className="flex items-center gap-4">
        <Link to="/dashboard" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
            <Zap className="w-5 h-5 text-on-primary" fill="currentColor" />
          </div>
          <span className="text-xl font-headline font-bold text-primary tracking-tight">
            {t('header.fieldConnect')}
          </span>
        </Link>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative">
          <button 
            onClick={() => setIsLangOpen(!isLangOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md hover:bg-surface-container-high transition-colors text-on-surface-variant font-medium text-sm border border-outline-variant"
          >
            <Globe className="w-4 h-4 text-primary" />
            <span className="font-bold uppercase">{language}</span>
            <ChevronDown className={cn("w-3 h-3 transition-transform", isLangOpen && "rotate-180")} />
          </button>

          {isLangOpen && (
            <>
              <div 
                className="fixed inset-0 z-10" 
                onClick={() => setIsLangOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-40 bg-surface-container-lowest border border-outline-variant rounded-lg shadow-xl z-20 py-1 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setLanguage(lang.code);
                      setIsLangOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center justify-between px-4 py-2 text-sm transition-colors hover:bg-surface-container-high",
                      language === lang.code ? "text-primary font-bold" : "text-on-surface-variant"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span>{lang.flag}</span>
                      <span>{lang.label}</span>
                    </div>
                    {language === lang.code && <Check className="w-4 h-4" />}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
        
        <Link to="/profile" className="w-10 h-10 rounded-lg overflow-hidden border border-outline-variant ml-2 bg-surface-container flex items-center justify-center hover:shadow-md transition-shadow">
          {profile?.displayName ? (
            <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(profile.displayName)}&background=003e6f&color=fff`} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <UserIcon className="w-5 h-5 text-on-surface-variant" />
          )}
        </Link>
      </div>
    </header>
  );
}
