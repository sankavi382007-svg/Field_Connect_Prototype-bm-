import React, { useState, useEffect } from 'react';
import { useFirebase } from '../../contexts/FirebaseContext';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  updateDoc, 
  addDoc, 
  serverTimestamp, 
  increment 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useTranslation } from '../../contexts/LanguageContext';
import { TranslatedText } from '../TranslatedText';
import { Issue } from '../../types';
import { 
  MapPin, 
  CheckCircle, 
  XCircle, 
  Award, 
  Zap, 
  ShieldCheck, 
  Heart, 
  Loader2, 
  MessageSquare, 
  Navigation,
  ListTodo,
  Activity,
  History,
  Info
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useNavigate, useLocation } from 'react-router-dom';

export default function VolunteerDashboard() {
  const { user, profile } = useFirebase();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [tasks, setTasks] = useState<Issue[]>([]);
  const [activeTasks, setActiveTasks] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const activeTab = location.pathname === '/active-tasks' ? 'active' :
                    location.pathname === '/impact' ? 'impact' : 'tasks';
  const [syncingGps, setSyncingGps] = useState(false);

  const setActiveTab = (tab: 'tasks' | 'active' | 'impact') => {
    const path = tab === 'active' ? '/active-tasks' :
                 tab === 'impact' ? '/impact' : '/dashboard';
    navigate(path);
  };

  // Fetch Assigned (Pending) Tasks
  useEffect(() => {
    if (!user) return;
    // An issue is in the "Tasks" queue if assigned to this volunteer but not yet accepted/declined
    const q = query(
      collection(db, 'issues'), 
      where('assignedVolunteerId', '==', user.uid),
      where('volunteerStatus', '==', 'pending')
    );
    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Issue)));
        setLoading(false);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'issues')
    );
    return unsubscribe;
  }, [user]);

  // Fetch Active Tasks (Accepted)
  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'issues'), 
      where('assignedVolunteerId', '==', user.uid),
      where('volunteerStatus', '==', 'accepted')
    );
    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        setActiveTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Issue)));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'issues')
    );
    return unsubscribe;
  }, [user]);

  const toggleStatus = async () => {
    if (!user || !profile) return;
    const newStatus = profile.status === 'active' ? 'away' : 'active';
    try {
      await updateDoc(doc(db, 'users', user.uid), { status: newStatus });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const captureGps = () => {
    if (!navigator.geolocation) return;
    setSyncingGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (!user) return;
        try {
          await updateDoc(doc(db, 'users', user.uid), {
            location: {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              address: `Sync: ${new Date().toLocaleTimeString()}`
            }
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
        } finally {
          setSyncingGps(false);
        }
      },
      () => setSyncingGps(false)
    );
  };

  const handleAccept = async (issueId: string) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'issues', issueId), {
        volunteerStatus: 'accepted',
        status: 'in_progress',
        updatedAt: serverTimestamp()
      });
      setActiveTab('active');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `issues/${issueId}`);
    }
  };

  const handleDecline = async (issueId: string) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'issues', issueId), {
        volunteerStatus: 'declined', // We keep record but unassign from active pool
        assignedVolunteerId: null,
        updatedAt: serverTimestamp()
      });
      await addDoc(collection(db, 'declines'), {
        issueId,
        volunteerId: user.uid,
        reason: 'Declined by volunteer',
        createdAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `issues/${issueId}`);
    }
  };

  const handleFinalizeCompletion = async (issueId: string) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'issues', issueId), {
        volunteerStatus: 'completed',
        updatedAt: serverTimestamp()
      });
      
      // Award points
      await updateDoc(doc(db, 'users', user.uid), {
        impactPoints: increment(100)
      });

      alert('Mission Finalized! Karma points awarded.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `issues/${issueId}`);
    }
  };

  return (
    <div className="flex-1 p-4 md:p-8 max-w-4xl mx-auto space-y-8 pb-32">
      {/* Header Section */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-6 rounded-3xl border border-outline-variant shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-3xl" />
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center border-2 border-primary/20 shadow-inner overflow-hidden">
            <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(profile?.displayName || 'V')}&background=003e6f&color=fff`} className="w-full h-full p-1" alt="Avatar" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-on-surface tracking-tight leading-none uppercase">
              {profile?.displayName}
            </h1>
            <p className="text-[10px] font-black text-outline uppercase tracking-[0.2em] mt-1 italic opacity-70">Sector Asset ID: {user?.uid.slice(0, 8)}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <div className="flex items-center gap-2 bg-surface-container p-2 rounded-2xl border border-outline-variant/30">
            <span className={cn(
              "w-2.5 h-2.5 rounded-full",
              profile?.status === 'active' ? "bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-outline"
            )} />
            <span className="text-[10px] font-black uppercase tracking-widest mr-2">
              {profile?.status === 'active' ? 'Active' : 'Away'}
            </span>
            <button 
              onClick={toggleStatus}
              className={cn(
                "px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all",
                profile?.status === 'active' ? "bg-white text-error border border-error/20" : "bg-primary text-on-primary"
              )}
            >
              {profile?.status === 'active' ? 'Switch Off' : 'Go Active'}
            </button>
          </div>

          {profile?.status === 'active' && (
            <button 
              onClick={captureGps}
              disabled={syncingGps}
              className="bg-secondary text-on-secondary p-3 rounded-2xl shadow-xl shadow-secondary/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 border border-white/20"
              title="Sync GPS Coordinates"
            >
              <Navigation className={cn("w-5 h-5", syncingGps ? "animate-spin" : "fill-current")} />
            </button>
          )}
        </div>
      </header>

      {/* Navigation Menu */}
      <nav className="flex justify-around bg-white p-1.5 rounded-3xl border border-outline-variant shadow-sm">
        {(['tasks', 'active', 'impact'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-4 px-6 rounded-2xl flex items-center justify-center gap-2 transition-all relative",
              activeTab === tab ? "bg-primary text-on-primary shadow-lg shadow-primary/20 font-black scale-[1.02]" : "text-outline font-bold hover:bg-surface-container"
            )}
          >
            {tab === 'tasks' && <ListTodo className="w-5 h-5" />}
            {tab === 'active' && <Activity className="w-5 h-5" />}
            {tab === 'impact' && <Award className="w-5 h-5" />}
            <span className="text-[11px] uppercase tracking-widest hidden sm:inline">{tab}</span>
            {tab === 'tasks' && tasks.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-error text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] border-2 border-white font-black shadow-sm">
                {tasks.length}
              </span>
            )}
          </button>
        ))}
      </nav>

      <main className="animate-in fade-in slide-in-from-bottom-4 duration-500 min-h-[400px]">
        {activeTab === 'tasks' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Assignment Queue</h3>
              <div className="flex items-center gap-2 text-[10px] font-bold text-outline uppercase tracking-widest">
                <TranslatedText text="Recent Transmissions" />
                <History className="w-4 h-4" />
              </div>
            </div>

            {loading ? (
              <div className="py-20 flex flex-col items-center gap-4">
                <Loader2 className="w-10 h-10 animate-spin text-primary" />
                <p className="text-[10px] font-black uppercase tracking-widest text-outline">Scanning Sector Frequencies...</p>
              </div>
            ) : tasks.length === 0 ? (
              <div className="py-20 bg-surface-container/30 rounded-3xl border-2 border-dashed border-outline-variant flex flex-col items-center justify-center gap-4 opacity-50">
                <ShieldCheck className="w-16 h-16 text-outline-variant" />
                <div className="text-center space-y-1">
                  <p className="text-sm font-black uppercase tracking-widest">Sector Stability Confirmed</p>
                  <p className="text-[10px] font-bold uppercase text-outline">No pending dispatches found.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {tasks.map(task => (
                  <div key={task.id} className="bg-white border border-outline-variant rounded-3xl p-6 space-y-6 hover:shadow-xl hover:border-primary transition-all group relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
                      <Zap className="w-24 h-24 text-primary" />
                    </div>
                    
                    <div className="space-y-3 relative z-10">
                      <div className="flex items-center gap-3">
                        <span className={cn(
                          "px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-[0.1em]",
                          task.priority === 'critical' ? "bg-error text-on-error animate-pulse" : "bg-primary/10 text-primary border border-primary/20"
                        )}>
                          {task.priority || 'Normal'} priority
                        </span>
                        <span className="text-[10px] font-black text-outline uppercase tracking-widest bg-surface-container px-2 py-1 rounded-lg">
                          Ref: {task.id.slice(0, 6)}
                        </span>
                      </div>
                      <h4 className="text-2xl font-black text-on-surface leading-tight tracking-tight">
                        <TranslatedText text={task.title || t('common.issue')} />
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] font-bold text-primary uppercase tracking-tight">
                        <MapPin className="w-4 h-4" />
                        <TranslatedText text={task.location?.address || 'Crisis Sector'} />
                      </div>
                    </div>

                    <div className="p-4 bg-surface-container rounded-2xl border border-outline-variant/30 min-h-[60px] relative z-10">
                      <p className="text-sm text-on-surface-variant font-medium leading-relaxed italic opacity-80">
                        <TranslatedText text={task.description} />
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 relative z-10">
                      <button 
                        onClick={() => handleAccept(task.id)}
                        className="bg-primary text-on-primary h-14 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all"
                      >
                        <Zap className="w-5 h-5 fill-current" /> Accept Mission
                      </button>
                      <button 
                        onClick={() => handleDecline(task.id)}
                        className="bg-white text-error h-14 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 border border-error/20 hover:bg-error-container/20 transition-all"
                      >
                        <XCircle className="w-5 h-5" /> Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'active' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Operational View</h3>
              <div className="px-3 py-1 bg-secondary/10 rounded-full flex items-center gap-2 border border-secondary/20">
                <Activity className="w-4 h-4 text-secondary animate-pulse" />
                <span className="text-[9px] font-black text-secondary uppercase tracking-widest">In Progress</span>
              </div>
            </div>

            {activeTasks.length === 0 ? (
              <div className="py-20 bg-surface-container/30 rounded-3xl border-2 border-dashed border-outline-variant flex flex-col items-center justify-center gap-4 text-outline/50 group">
                <Activity className="w-16 h-16 group-hover:scale-110 transition-transform" />
                <div className="text-center space-y-1">
                  <p className="text-sm font-black uppercase tracking-widest">No Active Missions</p>
                  <p className="text-[10px] font-bold uppercase tracking-tighter">Your current queue is empty.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-8">
                {activeTasks.map(task => (
                  <div key={task.id} className="bg-white border-2 border-primary rounded-3xl p-8 space-y-8 shadow-2xl relative shadow-primary/10 overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 rounded-r-full h-full bg-primary" />
                    
                    <div className="flex justify-between items-start gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3 flex-wrap">
                           <h4 className="text-3xl font-black text-primary leading-tight tracking-tight">
                             <TranslatedText text={task.title} />
                           </h4>
                           <span className="bg-primary/10 text-primary border border-primary/30 px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-sm">Assigned & Active</span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] font-black text-on-surface-variant uppercase tracking-widest bg-surface-container inline-flex px-3 py-1.5 rounded-full">
                          <MapPin className="w-4 h-4 text-secondary" />
                          <TranslatedText text={task.location?.address || 'Crisis Zone'} />
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => navigate(`/chat/${task.id}`)}
                        className="p-4 bg-primary text-on-primary rounded-2xl hover:brightness-110 transition-all shadow-xl shadow-primary/20 border border-white/20 shrink-0 group"
                        title="Open Communication Hub"
                      >
                        <MessageSquare className="w-7 h-7 group-hover:scale-110 transition-transform" />
                      </button>
                    </div>

                    <div className="bg-surface-container/50 p-6 rounded-3xl border border-outline-variant/30 space-y-4">
                       <h5 className="text-[10px] font-black text-outline uppercase tracking-[0.2em] flex items-center gap-2">
                         <ShieldCheck className="w-4 h-4" /> Operational Intelligence
                       </h5>
                       <p className="text-base font-medium text-on-surface leading-relaxed">
                         <TranslatedText text={task.description} />
                       </p>
                    </div>

                    <div className="flex flex-col gap-4">
                      <button 
                        disabled={task.status !== 'solved'}
                        onClick={() => handleFinalizeCompletion(task.id)}
                        className={cn(
                          "w-full h-16 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 transition-all",
                          task.status === 'solved' 
                            ? "bg-secondary text-on-secondary shadow-xl shadow-secondary/20 hover:scale-[1.02] active:scale-95" 
                            : "bg-surface-container text-outline cursor-not-allowed opacity-50 border border-outline-variant"
                        )}
                      >
                        <CheckCircle className="w-6 h-6" />
                        {task.status === 'solved' ? 'Stabilization Confirmed: Finalize Mission' : 'Pending Verification'}
                      </button>
                      
                      {task.status !== 'solved' && (
                        <div className="flex items-start gap-4 p-5 bg-amber-50 border border-amber-200 rounded-3xl">
                          <div className="p-2 bg-amber-200 rounded-xl">
                            <Clock className="w-5 h-5 text-amber-900" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs font-black text-amber-900 uppercase tracking-tight">Status: Review in Progress</p>
                            <p className="text-[10px] font-bold text-amber-800 uppercase leading-relaxed tracking-tighter opacity-80">
                              The Community Sector Head is currently validating the resolution. You will be cleared for rewards once the status switches to 'Solved'.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'impact' && (
          <div className="animate-in fade-in zoom-in-95 duration-500 space-y-8">
            <div className="bg-primary text-on-primary rounded-[2.5rem] p-10 relative overflow-hidden group shadow-2xl border-4 border-white">
               <div className="relative z-10 space-y-8">
                  <div className="flex justify-between items-start flex-wrap gap-6">
                    <div className="space-y-4">
                      <div className="p-4 bg-white/10 rounded-3xl w-24 h-24 flex items-center justify-center backdrop-blur shadow-2xl border border-white/20">
                        <Award className="w-12 h-12 text-secondary fill-current shadow-lg" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-4xl font-black uppercase italic tracking-tighter leading-none">Excellence Hub</h3>
                        <p className="text-[11px] font-black text-white/50 uppercase tracking-[0.3em]">Verified Field Performance</p>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end">
                       <div className="flex items-baseline gap-2">
                         <span className="text-7xl font-black tabular-nums leading-none tracking-tighter">{profile?.impactPoints || 0}</span>
                         <span className="text-xl font-black text-secondary uppercase">Units</span>
                       </div>
                       <p className="text-[10px] font-black uppercase tracking-widest mt-2 text-white/40 italic">Regional Rank: Top 0.5%</p>
                    </div>
                  </div>

                  <div className="pt-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-8">
                    {[
                      { name: 'Health Warrior', icon: Heart, color: 'text-rose-400', threshold: 500 },
                      { name: 'Crisis Ninja', icon: Zap, color: 'text-secondary', threshold: 200 },
                      { name: 'Sector Shield', icon: ShieldCheck, color: 'text-blue-300', threshold: 1000 },
                      { name: 'Arch Guardian', icon: Award, color: 'text-amber-400', threshold: 5000 },
                    ].map((badge, idx) => {
                      const hasBadge = (profile?.impactPoints || 0) >= badge.threshold;
                      return (
                        <div key={idx} className="flex flex-col items-center gap-4 group/badge">
                          <div className={cn(
                            "w-20 h-20 rounded-[2rem] flex items-center justify-center border-2 transition-all relative",
                            hasBadge 
                              ? "bg-white/20 border-white/40 scale-110 shadow-[0_0_30px_rgba(255,255,255,0.2)]" 
                              : "bg-black/20 border-white/5 opacity-20 grayscale"
                          )}>
                            <badge.icon className={cn("w-10 h-10", hasBadge ? badge.color : "text-white")} fill={hasBadge ? "currentColor" : "none"} />
                            {hasBadge && <div className="absolute -top-1 -right-1 bg-secondary w-5 h-5 rounded-full border-2 border-primary" />}
                          </div>
                          <div className="text-center space-y-1">
                            <span className="text-[10px] font-black uppercase tracking-tight block">
                              {badge.name}
                            </span>
                            <span className="text-[8px] font-bold uppercase opacity-50 block tracking-widest">
                              {badge.threshold} pts
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
               </div>
               {/* Decorative background effects */}
               <div className="absolute -right-32 -bottom-32 w-80 h-80 bg-secondary rounded-full blur-[100px] opacity-20 group-hover:scale-150 transition-transform duration-1000"></div>
               <div className="absolute left-1/4 top-1/4 w-40 h-40 bg-white rounded-full blur-[80px] opacity-10"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="md:col-span-2 bg-white border border-outline-variant p-8 rounded-[2rem] space-y-4 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8">
                    <Activity className="w-16 h-16 text-surface-container" />
                  </div>
                  <h4 className="font-black text-xs uppercase tracking-widest text-primary flex items-center gap-2">
                    <ListTodo className="w-4 h-4" /> Karma Progression
                  </h4>
                  <p className="text-sm font-medium text-on-surface-variant leading-relaxed max-w-md relative z-10">
                    Points are automatically calculated via edge computation once dispatches are verified by Sector Commanders. High karma units receive prioritized crisis transmissions and unlock specialized gear access.
                  </p>
               </div>
               <div className="bg-secondary p-8 rounded-[2rem] flex flex-col justify-between group shadow-xl shadow-secondary/10">
                  <Heart className="w-10 h-10 text-primary group-hover:scale-110 transition-transform" fill="currentColor" />
                  <div className="space-y-1">
                    <h4 className="font-black text-primary text-xl uppercase tracking-tighter leading-none italic">Mobilizer Elite</h4>
                    <p className="text-[9px] font-black text-primary/60 uppercase tracking-widest mt-2">Active sector participation</p>
                  </div>
               </div>
            </div>
          </div>
        )}
      </main>

      <style>{`
        .animate-spin-slow { animation: spin 4s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function Clock({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

function SyncIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  );
}
