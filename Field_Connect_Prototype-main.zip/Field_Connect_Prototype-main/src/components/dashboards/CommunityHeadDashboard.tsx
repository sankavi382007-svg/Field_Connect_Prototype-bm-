import React, { useState, useRef, useEffect } from 'react';
import { useFirebase } from '../../contexts/FirebaseContext';
import { GoogleGenAI } from '@google/genai';
import { 
  Camera, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Send, 
  Info, 
  CheckCircle, 
  Loader2, 
  MapPin, 
  ShieldCheck, 
  LayoutDashboard, 
  ListTodo, 
  FileBox, 
  RefreshCcw, 
  AlertTriangle, 
  ChevronRight, 
  Search, 
  Languages 
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { collection, addDoc, doc, setDoc, serverTimestamp, query, where, onSnapshot, updateDoc } from 'firebase/firestore';
import { cn } from '../../lib/utils';
import { addToSyncQueue, getSyncQueue, removeFromSyncQueue } from '../../lib/offline';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from '../../contexts/LanguageContext';
import { TranslatedText } from '../TranslatedText';
import { Issue } from '../../types';

interface ExtractedIssue {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  address: string;
}

export default function CommunityHeadDashboard() {
  const { user, profile, isOnline } = useFirebase();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const [images, setImages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedIssues, setExtractedIssues] = useState<ExtractedIssue[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [pendingSync, setPendingSync] = useState<any[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'issues'), where('communityHeadId', '==', user.uid));
    const unsub = onSnapshot(q, (sn) => {
      setIssues(sn.docs.map(d => ({ id: d.id, ...d.data() } as Issue)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'issues'));
    return unsub;
  }, [user]);

  useEffect(() => {
    const fetchSync = async () => {
      const queue = await getSyncQueue();
      setPendingSync(queue);
    };
    if (location.pathname === '/sync') fetchSync();
  }, [location.pathname, isOnline]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    const newImages: string[] = [];
    
    for (const file of files) {
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      newImages.push(base64);
    }
    setImages((prev) => [...prev, ...newImages]);
  };

  const processImages = async () => {
    if (images.length === 0) return;
    setIsProcessing(true);
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY is not configured.');
      }
      const ai = new GoogleGenAI({ apiKey });

      const imageParts = images.map((img) => ({
        inlineData: {
          mimeType: 'image/jpeg',
          data: img.split(',')[1],
        },
      }));

      const prompt = `Perform OCR on these handwritten notes and regional text. 
      The primary language preference of the community head is: ${profile?.languagePreference || 'General (Hindi, Telugu, Tamil, Kannada, Bengali, English)'}.
      Focus on accurately extracting text in this language if present.
      Translate all findings to English for management, but preserve the core intent. 
      Identify specific community issues like 'Broken Pump', 'Roof Leakage', etc.
      Return the output as a JSON array of objects with fields: title, description, priority (low/medium/high/critical), and address.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: [{ text: prompt }, ...imageParts] }
      });

      const text = (response.text || '').replace(/```json\n?|```/g, '').trim();

      const results = JSON.parse(text || '[]');
      setExtractedIssues(results.map((r: any) => ({ ...r, id: Math.random().toString(36).substr(2, 9) })));
      setImages([]);
    } catch (error: any) {
      console.error('AI Processing failed:', error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED')) {
        alert('AI Quota reached. Please try again later or check your API key billings.');
      } else {
        alert('AI Processing failed. Please ensure your Gemini API key is configured in the settings.');
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const updateIssue = (id: string, field: keyof ExtractedIssue, value: string) => {
    setExtractedIssues(prev => prev.map(issue => issue.id === id ? { ...issue, [field]: value } : issue));
  };

  const removeIssue = (id: string) => {
    setExtractedIssues(prev => prev.filter(issue => issue.id !== id));
  };

  const submitToDatabase = async () => {
    if (extractedIssues.length === 0) return;
    setIsSubmitting(true);
    try {
      for (const issue of extractedIssues) {
        const issueData = {
          title: issue.title,
          description: issue.description,
          priority: issue.priority,
          location: { address: issue.address, lat: 0, lng: 0 },
          status: 'reported',
          communityHeadId: user?.uid,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          region: profile?.assignedRegion || 'General'
        };

        if (isOnline) {
          const docRef = await addDoc(collection(db, 'issues'), issueData);
          await setDoc(doc(db, 'chats', docRef.id), {
            id: docRef.id,
            issueId: docRef.id,
            memberIds: [user?.uid],
            createdAt: serverTimestamp()
          });
        } else {
          await addToSyncQueue('issues', issueData, 'create');
        }
      }
      setExtractedIssues([]);
      alert('Issues submitted for verification!');
    } catch (error) {
      console.error('Submission failed:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateStatus = async (issueId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'issues', issueId), {
        status: newStatus,
        updatedAt: serverTimestamp()
      });
      if (newStatus === 'solved') {
        // Notify NGO logic or special collection entry
        await addDoc(collection(db, 'notifications'), {
          type: 'issue_solved',
          issueId,
          communityHeadId: user?.uid,
          createdAt: serverTimestamp()
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'issues/' + issueId);
    }
  };

  const triggerEscalation = async (issueId: string, reason: string) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'escalations'), {
        issueId,
        communityHeadId: user.uid,
        reason,
        createdAt: serverTimestamp()
      });
      // Also update priority to critical if escalated
      await updateDoc(doc(db, 'issues', issueId), {
        priority: 'critical',
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'escalations');
    }
  };

  const tabs = [
    { id: 'dashboard', label: 'Surveys', icon: LayoutDashboard },
    { id: 'issues', label: 'Issues', icon: ListTodo },
    { id: 'reports', label: 'Analysis', icon: FileBox },
    { id: 'sync', label: 'Cloud Sync', icon: RefreshCcw },
  ] as const;

  return (
    <div className="flex-1 max-w-5xl mx-auto w-full p-4 md:p-8 space-y-8 pb-32">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-bold text-primary tracking-tight">{t('dashboard.sectorHub')}</h1>
          <p className="text-body-md text-on-surface-variant flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" /> <TranslatedText text={profile?.assignedRegion || 'Central Sector'} /> {t('dashboard.operationUnit')}
          </p>
        </div>
      </div>

      {/* Connectivity Banner */}
      <div className={cn(
        "flex items-center justify-between px-6 py-2 rounded border text-[11px] font-bold uppercase tracking-[0.2em] transition-colors",
        isOnline ? "bg-secondary-container/20 border-secondary/20 text-secondary" : "bg-error-container/20 border-error/20 text-error animate-pulse"
      )}>
        <span className="flex items-center gap-2">
          <div className={cn("w-2 h-2 rounded-full", isOnline ? "bg-secondary" : "bg-error animate-ping")} />
          {isOnline ? t('dashboard.systemSync') : t('dashboard.edgeComputing')}
        </span>
        {pendingSync.length > 0 && <span className="text-error">{pendingSync.length} {t('dashboard.pendingSync')}</span>}
      </div>

      {/* Main Content Area */}
      <main className="animate-in fade-in duration-500">
        {(location.pathname === '/dashboard' || location.pathname === '/') && (
          <div className="space-y-8">
            <section className="bg-surface-container p-8 rounded-lg border border-outline-variant space-y-6">
              <div className="space-y-2">
                <h2 className="text-xl font-headline font-bold text-on-surface">{t('dashboard.paperDigitization')}</h2>
                <p className="text-body-md text-on-surface-variant">{t('dashboard.paperDigitizationDesc')}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-4 p-12 bg-primary text-on-primary rounded border border-outline-variant shadow hover:brightness-110 active:scale-95 transition-all"
                >
                  <Camera className="w-10 h-10" />
                  <span className="font-bold text-xs uppercase tracking-widest">{t('dashboard.captureScripts')}</span>
                </button>
                <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
                
                <button 
                  onClick={processImages}
                  disabled={images.length === 0 || isProcessing}
                  className={cn(
                    "flex flex-col items-center justify-center gap-4 p-12 rounded border border-outline-variant transition-all",
                    images.length > 0 ? "bg-surface-container-lowest text-primary border-primary shadow-sm" : "bg-surface-container-high text-outline cursor-not-allowed opacity-50"
                  )}
                >
                  {isProcessing ? <Loader2 className="w-10 h-10 animate-spin" /> : <Languages className="w-10 h-10" />}
                  <span className="font-bold text-xs uppercase tracking-widest">
                    {isProcessing ? t('dashboard.processing') : t('dashboard.extract')}
                  </span>
                </button>
              </div>

              {images.length > 0 && (
                <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                  {images.map((img, i) => (
                    <div key={i} className="relative w-32 h-32 shrink-0 group">
                      <img src={img} className="w-full h-full object-cover rounded border border-outline-variant group-hover:border-primary transition-all" />
                      <button onClick={() => setImages(images.filter((_, idx) => idx !== i))} className="absolute -top-2 -right-2 bg-error text-on-error p-1.5 rounded shadow-lg">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {extractedIssues.length > 0 && (
              <section className="space-y-6">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-xl font-headline font-bold text-on-surface">{t('dashboard.fieldMetadata')}</h3>
                  <button onClick={() => setExtractedIssues([])} className="text-error text-[10px] font-bold uppercase tracking-widest hover:underline">{t('dashboard.discardBatch')}</button>
                </div>
                <div className="bg-surface-container-lowest rounded-lg border border-outline-variant overflow-hidden shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-surface-container text-on-surface-variant text-[11px] font-bold uppercase tracking-widest border-b border-outline-variant">
                        <tr>
                          <th className="px-6 py-4">{t('dashboard.discovery')}</th>
                          <th className="px-6 py-4">{t('dashboard.triage')}</th>
                          <th className="px-6 py-4 text-right">{t('dashboard.verification')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-outline-variant">
                        {extractedIssues.map((issue) => (
                          <tr key={issue.id} className="hover:bg-surface-container-low transition-colors">
                            <td className="px-6 py-5">
                              <div className="space-y-2 max-w-lg">
                                <input 
                                  value={issue.title} 
                                  onChange={(e) => updateIssue(issue.id, 'title', e.target.value)}
                                  className="font-bold text-on-surface bg-transparent border-none p-0 focus:ring-0 w-full"
                                  placeholder="Issue Focus"
                                />
                                <textarea 
                                  value={issue.description}
                                  onChange={(e) => updateIssue(issue.id, 'description', e.target.value)}
                                  className="text-xs text-on-surface-variant bg-transparent border-none p-0 focus:ring-0 w-full resize-none h-8"
                                  placeholder="Evidence details..."
                                />
                                <div className="flex items-center gap-2 text-[9px] font-bold text-primary uppercase">
                                  <MapPin className="w-3 h-3" />
                                  <input 
                                    value={issue.address}
                                    onChange={(e) => updateIssue(issue.id, 'address', e.target.value)}
                                    className="bg-transparent border-none p-0 focus:ring-0 w-full"
                                    placeholder="Deployment address"
                                  />
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-5">
                              <select 
                                value={issue.priority}
                                onChange={(e) => updateIssue(issue.id, 'priority', e.target.value as any)}
                                className={cn(
                                  "text-[10px] font-bold uppercase rounded p-1 border border-outline-variant bg-surface-container focus:ring-0",
                                  issue.priority === 'critical' ? "text-error" : "text-on-surface-variant"
                                )}
                              >
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                                <option value="critical">Critical</option>
                              </select>
                            </td>
                            <td className="px-6 py-5 text-right space-x-2">
                              <button onClick={() => navigate('/issues')} className="text-primary font-bold text-[10px] uppercase tracking-widest hover:underline">Verify in Log</button>
                              <button onClick={() => removeIssue(issue.id)} className="p-2 text-error hover:bg-error/10 rounded-full transition-colors">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="p-6 bg-surface-container border-t border-outline-variant">
                    <button 
                      onClick={submitToDatabase}
                      disabled={isSubmitting}
                      className="w-full h-12 bg-primary text-on-primary rounded font-bold text-xs uppercase tracking-widest shadow hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3"
                    >
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                      {t('dashboard.commitLedger')}
                    </button>
                  </div>
                </div>
              </section>
            )}
          </div>
        )}

        {location.pathname === '/issues' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-outline-variant pb-2">
              <h2 className="text-xl font-headline font-bold text-on-surface uppercase tracking-tight">{t('dashboard.operationLog')}</h2>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {issues.length === 0 ? (
                <div className="text-center py-20 bg-surface-container-low rounded-lg border border-dashed border-outline-variant flex flex-col items-center justify-center opacity-50">
                  <ShieldCheck className="w-12 h-12 mb-2" />
                  <p className="font-bold uppercase tracking-widest text-xs">{t('dashboard.stabilizationComplete')}</p>
                </div>
              ) : (
                issues.map((issue) => (
                  <div key={issue.id} className="bg-surface-container-lowest border border-outline-variant rounded-lg p-6 hover:border-primary transition-all shadow-sm group">
                    <div className="flex justify-between items-start mb-4">
                      <div className="space-y-1">
                        <h4 className="text-xl font-bold text-on-surface leading-tight">
                          <TranslatedText text={issue.title} />
                        </h4>
                        <p className="text-body-md text-on-surface-variant leading-relaxed">
                          <TranslatedText text={issue.description} />
                        </p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <select 
                          value={issue.status}
                          onChange={(e) => updateStatus(issue.id, e.target.value)}
                          className="bg-surface-container text-on-surface font-bold text-[11px] uppercase tracking-widest border border-outline-variant rounded p-2 focus:ring-1 focus:ring-primary"
                        >
                          <option value="reported">Reported</option>
                          <option value="in_progress">In Progress</option>
                          <option value="solved">Solved</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 pt-4 border-t border-outline-variant">
                      <div className="flex items-center gap-2 text-[11px] font-bold text-on-surface-variant uppercase tracking-widest">
                        <MapPin className="w-3.5 h-3.5 text-primary" /> <TranslatedText text={issue.location?.address || issue.address} />
                      </div>
                      <div className="flex-1" />
                      <button onClick={() => navigate(`/chat/${issue.id}`)} className="text-primary font-bold text-[11px] uppercase tracking-widest hover:underline flex items-center gap-1">
                        {t('dashboard.operationalHub')} <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {location.pathname === '/reports' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <section className="space-y-6">
              <h2 className="text-xl font-headline font-bold text-secondary uppercase tracking-tight border-b border-secondary/20 pb-2">{t('dashboard.resolvedDeployments')}</h2>
              <div className="space-y-4">
                {issues.filter(i => i.status === 'solved').map(issue => (
                  <div key={issue.id} className="bg-secondary-container/10 border border-secondary/20 p-6 rounded-lg opacity-80">
                    <h4 className="font-bold text-secondary">
                      <TranslatedText text={issue.title} />
                    </h4>
                    <p className="text-xs text-on-surface-variant mt-1">Verified stabilization complete by NGO Unit.</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="space-y-6">
              <h2 className="text-xl font-headline font-bold text-error uppercase tracking-tight border-b border-error/20 pb-2">{t('dashboard.stagnantFindings')}</h2>
              <div className="space-y-4">
                {issues.filter(i => i.status !== 'solved').map(issue => (
                  <div key={issue.id} className="bg-surface-container-low border border-outline-variant p-6 rounded-lg space-y-4">
                    <div className="flex justify-between items-start">
                      <h4 className="font-bold text-on-surface">
                        <TranslatedText text={issue.title} />
                      </h4>
                      <span className="text-[10px] font-bold text-error uppercase animate-pulse">{t('dashboard.awaitingSync')}</span>
                    </div>
                    <button 
                      onClick={() => triggerEscalation(issue.id, 'Stagnant issue requiring immediate NGO prioritization')}
                      className="w-full py-2 bg-error text-on-error rounded font-bold text-[10px] uppercase tracking-widest hover:brightness-110 transition-all shadow-sm"
                    >
                      {t('dashboard.escalateNgo')}
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {location.pathname === '/sync' && (
          <div className="space-y-8">
            <div className="bg-surface-container border border-outline-variant p-12 rounded-lg text-center space-y-6 relative overflow-hidden">
              <RefreshCcw className={cn("w-16 h-16 mx-auto transition-all", !isOnline ? "text-error opacity-20" : "text-secondary animate-spin-slow")} />
              <div className="space-y-2">
                <h2 className="text-2xl font-headline font-bold text-on-surface">{t('dashboard.pwaResilience')}</h2>
                <p className="text-body-md text-on-surface-variant max-w-lg mx-auto">
                  {t('dashboard.pwaResilienceDesc')}
                </p>
              </div>
            </div>

            <div className="bg-surface-container-lowest rounded-lg border border-outline-variant overflow-hidden shadow-sm">
              <div className="p-4 bg-surface-container font-bold text-[11px] tracking-widest uppercase border-b border-outline-variant">{t('dashboard.edgeStorage')}</div>
              <div className="divide-y divide-outline-variant">
                {pendingSync.length > 0 ? pendingSync.map((item) => (
                  <div key={item.id} className="p-6 flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="font-bold text-on-surface uppercase tracking-tight">{item.type} {item.collection}</div>
                      <div className="text-[10px] text-on-surface-variant font-medium">Capture Timestamp: {new Date(item.createdAt).toLocaleTimeString()}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-bold px-2 py-1 rounded bg-error-container text-on-error-container uppercase tracking-widest">{t('dashboard.awaitingLink')}</span>
                      <button onClick={() => removeFromSyncQueue(item.id)} className="text-error hover:scale-110 transition-transform">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )) : (
                  <div className="p-12 text-center text-on-surface-variant italic font-medium uppercase tracking-widest text-xs opacity-50">
                    {t('dashboard.noUnsynced')}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .animate-spin-slow { animation: spin 3s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function SyncIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  );
}
