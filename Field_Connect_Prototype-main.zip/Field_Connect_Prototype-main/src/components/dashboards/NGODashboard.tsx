import React, { useState, useEffect } from 'react';
import { useFirebase } from '../../contexts/FirebaseContext';
import { collection, query, onSnapshot, doc, updateDoc, getDocs, where, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from '../../contexts/LanguageContext';
import { TranslatedText } from '../TranslatedText';
import { Issue, UserProfile, Escalation, Decline } from '../../types';
import { Activity, AlertTriangle, UserMinus, Zap, CheckCircle, Info, Loader2, Sparkles, Map as MapIcon, Users, MapPin, Search, Filter, ShieldCheck, ChevronRight, BarChart3 } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { cn } from '../../lib/utils';

// Removed top-level ai constant
export default function NGODashboard() {
  const { isOnline } = useFirebase();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [activeVolunteers, setActiveVolunteers] = useState<UserProfile[]>([]);
  const [escalations, setEscalations] = useState<Escalation[]>([]);
  const [declines, setDeclines] = useState<Decline[]>([]);
  const [isMatching, setIsMatching] = useState(false);
  const [matchResult, setMatchResult] = useState<string | null>(null);

  // Determine active view based on path
  const view = location.pathname === '/triage' ? 'triage' :
               location.pathname === '/match' ? 'match' :
               location.pathname === '/bottlenecks' ? 'heatmap' : 'fleet';

  const setView = (newView: 'triage' | 'fleet' | 'heatmap' | 'match') => {
    const path = newView === 'triage' ? '/triage' :
                 newView === 'match' ? '/match' :
                 newView === 'heatmap' ? '/bottlenecks' : '/dashboard';
    navigate(path);
  };

  const displayedIssues = issues;
  const displayedVolunteers = activeVolunteers;

  useEffect(() => {
    const qIssues = query(collection(db, 'issues'));
    const unsubIssues = onSnapshot(qIssues, 
      (sn) => setIssues(sn.docs.map(d => ({ id: d.id, ...d.data() } as Issue))),
      (err) => handleFirestoreError(err, OperationType.GET, 'issues')
    );

    const qVols = query(collection(db, 'users'), where('role', '==', 'volunteer'));
    const unsubVols = onSnapshot(qVols, 
      (sn) => setActiveVolunteers(sn.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile))),
      (err) => handleFirestoreError(err, OperationType.GET, 'users')
    );

    const qEsc = query(collection(db, 'escalations'), limit(5));
    const unsubEsc = onSnapshot(qEsc, 
      (sn) => setEscalations(sn.docs.map(d => ({ id: d.id, ...d.data() } as any))),
      (err) => handleFirestoreError(err, OperationType.GET, 'escalations')
    );

    const qDec = query(collection(db, 'declines'), limit(5));
    const unsubDec = onSnapshot(qDec, 
      (sn) => setDeclines(sn.docs.map(d => ({ id: d.id, ...d.data() } as any))),
      (err) => handleFirestoreError(err, OperationType.GET, 'declines')
    );

    return () => {
      unsubIssues();
      unsubVols();
      unsubEsc();
      unsubDec();
    };
  }, []);

  const runSmartMatch = async () => {
    setIsMatching(true);
    setMatchResult(null);
    try {
      const openIssues = issues.filter(i => i.status === 'reported');
      
      const volunteersData = activeVolunteers.map(v => ({
        uid: v.uid,
        name: v.displayName,
        skills: v.skills || [],
        location: v.location || { lat: 0, lng: 0 }
      }));

      const input = {
        issues: openIssues.map(i => ({
          id: i.id,
          title: i.title,
          priority: i.priority,
          location: i.location
        })),
        volunteers: volunteersData
      };

      const prompt = `Act as an expert logistics coordinator. 
      Pair active volunteers with the most critical needs based primarily on GPS Proximity and secondarily on Skill Set matching the issue title/description.
      Return a summary of instructions for the NGO to approve matches.`;

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY is not configured.');
      }
      const ai = new GoogleGenAI({ apiKey });

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `${prompt}\nData: ${JSON.stringify(input)}`
      });

      setMatchResult(response.text || 'No matches identified.');
    } catch (error: any) {
      console.error('Smart Match failed:', error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED')) {
        alert('AI Quota reached. Deployment optimization temporarily unavailable.');
      } else {
        alert('Matching algorithm error. Please check your Gemini API key context.');
      }
    } finally {
      setIsMatching(false);
    }
  };

  const criticalIssues = displayedIssues.filter(i => i.priority === 'critical');
  const solvedCount = displayedIssues.filter(i => i.status === 'solved').length;

  return (
    <div className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full space-y-8 pb-24">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-bold text-on-surface leading-tight text-primary">{t('nav.fleet')} Command Center</h1>
          <p className="text-body-md text-on-surface-variant">Regional oversight and resource coordination unit.</p>
        </div>
        
        <div className="flex bg-surface-container rounded-lg p-1 border border-outline-variant overflow-x-auto no-scrollbar">
          {(['fleet', 'triage', 'match', 'heatmap'] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={cn(
                "px-4 py-2 rounded text-[11px] font-bold uppercase tracking-widest transition-all whitespace-nowrap min-w-[100px]",
                view === v ? "bg-primary text-on-primary shadow-sm" : "text-on-surface-variant hover:bg-surface-container-high"
              )}
            >
              {v === 'fleet' ? t('nav.fleet') + ' Overview' : v === 'heatmap' ? t('nav.bottlenecks') : t(`nav.${v}`)}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Activity, label: t('nav.issues'), value: displayedIssues.length, color: 'text-primary' },
          { icon: AlertTriangle, label: t('nav.triage'), value: criticalIssues.length, color: 'text-error' },
          { icon: CheckCircle, label: t('dashboard.sectorStability'), value: solvedCount, color: 'text-secondary' },
          { icon: Users, label: t('nav.fleet'), value: displayedVolunteers.length, color: 'text-primary' }
        ].map((stat, idx) => (
          <div key={idx} className="bg-surface-container-low p-6 rounded-lg border border-outline-variant shadow-sm space-y-3 group hover:border-primary transition-all">
            <stat.icon className={cn("w-6 h-6", stat.color)} />
            <div className="space-y-1">
              <div className="text-3xl font-headline font-bold text-on-surface tabular-nums">{stat.value}</div>
              <div className="text-[11px] font-bold uppercase tracking-widest text-on-surface-variant">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <section className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between border-b border-outline-variant pb-2">
            <h2 className="text-xl font-headline font-bold text-on-surface">
              {view === 'triage' ? t('nav.triage') : 
               view === 'fleet' ? t('nav.fleet') : 
               view === 'heatmap' ? t('nav.bottlenecks') : t('nav.match')}
            </h2>
            {view === 'triage' && (
              <span className="text-[10px] font-bold bg-primary-container text-on-primary-container px-2 py-1 rounded">{t('dashboard.systemSync')}</span>
            )}
          </div>

          {(view === 'match' || matchResult) && (
            <div className="bg-surface-container border border-outline-variant p-8 rounded-lg animate-in fade-in duration-500 relative transition-all shadow-sm">
               <div className="flex items-start justify-between mb-8">
                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-primary rounded flex items-center justify-center text-on-primary">
                     <Sparkles className="w-6 h-6" />
                   </div>
                   <div className="space-y-1">
                     <h3 className="text-xl font-headline font-bold text-on-surface leading-none">Deployment Optimizer</h3>
                     <p className="text-[11px] font-bold text-on-surface-variant uppercase tracking-widest">Logic: Proximity & Skill Proficiency</p>
                   </div>
                 </div>

                 {!matchResult && (
                    <button 
                      onClick={runSmartMatch}
                      disabled={isMatching}
                      className="bg-primary text-on-primary h-12 px-6 rounded font-bold text-xs uppercase tracking-widest flex items-center gap-2 hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
                    >
                      {isMatching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                      Sync Intelligence
                    </button>
                 )}
               </div>

               {matchResult ? (
                 <div className="space-y-6">
                   <div className="prose prose-sm max-w-none text-on-surface font-medium leading-relaxed bg-surface-container-low p-6 rounded border border-outline-variant italic">
                     <div className="whitespace-pre-wrap font-body text-sm">{matchResult}</div>
                   </div>
                   <div className="flex gap-4">
                     <button className="flex-1 bg-primary text-on-primary h-12 rounded font-bold uppercase text-[11px] tracking-widest hover:brightness-110 active:scale-95 transition-all">
                       Approve Dispatch Orders
                     </button>
                     <button 
                      onClick={() => setMatchResult(null)}
                      className="px-6 h-12 border border-outline text-on-surface font-bold uppercase text-[11px] tracking-widest rounded hover:bg-surface-container-high transition-all"
                     >
                       Regenerate
                     </button>
                   </div>
                 </div>
               ) : (
                 <div className="py-12 text-center space-y-4">
                    <BarChart3 className="w-12 h-12 text-outline-variant mx-auto" />
                    <p className="text-on-surface font-bold uppercase tracking-widest text-sm">Ready for synchronization</p>
                    <p className="text-[11px] text-on-surface-variant uppercase tracking-widest max-w-xs mx-auto font-medium">Initiate analysis to match {displayedIssues.filter(i => i.status === 'reported').length} field needs with verified units.</p>
                 </div>
               )}
            </div>
          )}

          {view === 'triage' && (
            <div className="bg-surface-container-lowest rounded-lg border border-outline-variant overflow-hidden shadow-sm">
               <div className="p-4 bg-surface-container font-bold text-[11px] tracking-widest text-on-surface-variant uppercase border-b border-outline-variant">Operational Queue</div>
               <div className="divide-y divide-outline-variant">
                  {displayedIssues.length > 0 ? displayedIssues.map(issue => (
                    <div key={issue.id} className="p-5 hover:bg-surface-container-low flex items-center justify-between group transition-colors">
                      <div className="space-y-1">
                        <div className="font-bold text-lg text-on-surface group-hover:text-primary transition-colors">
                          <TranslatedText text={issue.title || issue.description} />
                        </div>
                        <div className="flex items-center gap-2 text-[11px] font-medium text-on-surface-variant uppercase tracking-tight">
                          <MapPin className="w-3.5 h-3.5 text-primary" /> <TranslatedText text={issue.location?.address || issue.address} />
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={cn(
                          "px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest",
                          issue.priority === 'critical' ? "bg-error text-on-error" : 
                          issue.priority === 'high' ? "bg-error-container text-on-error-container" : "bg-surface-container-high text-on-surface-variant"
                        )}>
                          {issue.priority}
                        </span>
                        <ChevronRight className="w-5 h-5 text-outline-variant group-hover:text-primary transition-colors" />
                      </div>
                    </div>
                  )) : (
                    <div className="p-12 text-center text-on-surface-variant font-medium uppercase tracking-widest text-xs opacity-50">
                      Operational queue is currently clear.
                    </div>
                  )}
               </div>
            </div>
          )}

          {view === 'fleet' && (
            <div className="space-y-8 animate-in fade-in duration-500">
              {['North Sector', 'South Sector', 'East Sector', 'West Sector'].map(region => {
                const regionalVols = displayedVolunteers.filter(v => v.address?.includes(region));
                if (regionalVols.length === 0) return null;
                
                return (
                  <div key={region} className="space-y-4">
                    <div className="flex items-center gap-2 border-l-4 border-primary pl-3">
                       <h3 className="font-headline font-bold text-lg text-on-surface"><TranslatedText text={region} /> Fleet</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {regionalVols.map(vol => (
                        <div key={vol.uid} className="bg-surface-container-low border border-outline-variant rounded-lg p-5 space-y-4 hover:border-primary transition-all group shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-primary-container rounded flex items-center justify-center text-on-primary-container font-bold text-lg border border-outline-variant">
                                {vol.displayName[0]}
                              </div>
                              <div>
                                <div className="font-bold text-on-surface leading-tight text-lg">
                                  <TranslatedText text={vol.displayName} />
                                </div>
                                <div className="text-[11px] font-bold text-on-surface-variant uppercase tracking-widest">{vol.status || t('profile.activeNow')}</div>
                              </div>
                            </div>
                            {vol.status === 'pending' && (
                              <button 
                                onClick={() => updateDoc(doc(db, 'users', vol.uid), { status: 'active' })}
                                className="bg-secondary text-on-secondary p-2 rounded hover:brightness-110 transition-all shadow"
                              >
                                <CheckCircle className="w-5 h-5" />
                              </button>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {(vol.skills?.length ? vol.skills : ['Support Specialist']).slice(0, 3).map(skill => (
                              <span key={skill} className="px-2 py-0.5 bg-surface-variant border border-outline-variant rounded text-[10px] font-bold uppercase text-on-surface-variant tracking-tight">
                                <TranslatedText text={skill} />
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
              {displayedVolunteers.length === 0 && (
                <div className="bg-surface-container-low p-12 rounded-lg border border-dashed border-outline-variant text-center space-y-3">
                   <Users className="w-12 h-12 text-outline-variant mx-auto" />
                   <p className="text-on-surface-variant font-bold uppercase tracking-widest text-xs">No active units registered in database.</p>
                </div>
              )}
            </div>
          )}

          {view === 'heatmap' && (
            <div className="bg-surface-container-high rounded-lg p-8 border border-outline-variant min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden transition-all shadow-sm">
               <div className="absolute inset-0 opacity-10 pointer-events-none">
                 <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
                    </pattern>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                 </svg>
               </div>
               
               <h3 className="text-2xl font-headline font-bold text-primary mb-8 relative z-10">Regional Capacity Heatmap</h3>
               
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 relative z-10 w-full max-w-2xl px-6">
                   <div className="col-span-full bg-surface-container-lowest p-8 rounded-lg border border-outline-variant text-center space-y-4 shadow-md bg-opacity-80 backdrop-blur">
                     <ShieldCheck className="w-12 h-12 text-secondary mx-auto" />
                     <h4 className="font-headline font-bold text-on-surface text-lg">Sector Scan: Stable</h4>
                     <p className="text-body-md text-on-surface-variant mb-4">No critical capacity bottlenecks or resource shortages detected in active sectors.</p>
                     <div className="text-[11px] font-bold text-secondary uppercase tracking-[0.2em] animate-pulse">Establishing continuous monitoring...</div>
                   </div>
               </div>
            </div>
          )}
        </section>

        {/* Alerts Center */}
        <section className="space-y-6">
          <h2 className="text-xl font-headline font-bold text-on-surface px-1">Critical Advisories</h2>
          
          <div className="space-y-4">
            {escalations.length > 0 && escalations.map(esc => (
               <div key={esc.id} className="bg-error-container border border-error p-6 rounded-lg space-y-4 shadow-sm animate-in slide-in-from-right-2">
                 <div className="flex justify-between items-center pb-2 border-b border-error/20">
                    <span className="flex items-center gap-2 text-[11px] font-bold text-on-error-container uppercase tracking-widest">
                      <AlertTriangle className="w-4 h-4 text-error" /> Sector Escalation
                    </span>
                 </div>
                 <p className="text-sm font-medium text-on-error-container leading-relaxed">Structural deadlock reported. Urgent logistical bypass or intervention required in local sector.</p>
                 <button className="w-full bg-error text-on-error py-3 rounded font-bold text-[11px] uppercase tracking-widest hover:brightness-110 transition-all shadow-md">
                   Deploy Intervention Unit
                 </button>
               </div>
            ))}

            {declines.length > 0 && declines.map(dec => (
              <div key={dec.id} className="bg-surface-container border border-outline-variant p-6 rounded-lg space-y-4 shadow-sm">
                <div className="flex justify-between items-center pb-2 border-b border-outline-variant">
                   <span className="flex items-center gap-2 text-[11px] font-bold text-on-surface-variant uppercase tracking-widest">
                     <UserMinus className="w-4 h-4" /> Personnel Conflict
                   </span>
                </div>
                <p className="text-sm font-medium text-on-surface leading-tight leading-relaxed">A specialized unit has declined the recent deployment instruction. Reason: <span className="font-bold">{dec.reason}</span></p>
                <button 
                  onClick={runSmartMatch}
                  className="w-full bg-primary text-on-primary py-3 rounded font-bold text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-md hover:brightness-110 active:scale-95 transition-all"
                >
                   Reassign Resources
                </button>
              </div>
            ))}

            {escalations.length === 0 && declines.length === 0 && (
              <div className="text-center py-20 bg-surface-container-low rounded-lg border border-dashed border-outline-variant">
                <ShieldCheck className="w-10 h-10 text-secondary mx-auto mb-4 opacity-30" />
                <p className="text-[11px] text-on-surface-variant font-bold uppercase tracking-widest">System Synchronized</p>
                <p className="text-[10px] text-outline mt-1 font-medium italic">Scanning regional frequencies...</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
