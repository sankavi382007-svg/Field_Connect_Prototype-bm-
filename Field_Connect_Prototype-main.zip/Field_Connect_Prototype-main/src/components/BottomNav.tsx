import React from 'react';
import { NavLink } from 'react-router-dom';
import { useFirebase } from '../contexts/FirebaseContext';
import { 
  LayoutDashboard, 
  MapPin, 
  PlusCircle, 
  RefreshCw, 
  CheckSquare, 
  Activity, 
  Award,
  Truck,
  Filter,
  Zap,
  BarChart3,
  MessageSquare,
  ListTodo,
  FileBox,
  RefreshCcw
} from 'lucide-react';
import { useTranslation } from '../contexts/LanguageContext';
import { cn } from '../lib/utils';

export default function BottomNav() {
  const { profile } = useFirebase();
  const { t } = useTranslation();

  if (!profile || !profile.isOnboarded) return null;

  const getNavItems = () => {
    switch (profile.role) {
      case 'community_head':
        return [
          { label: t('nav.surveys'), icon: LayoutDashboard, path: '/dashboard' },
          { label: t('nav.issues'), icon: ListTodo, path: '/issues' },
          { label: t('nav.analysis'), icon: FileBox, path: '/reports' },
          { label: t('nav.sync'), icon: RefreshCcw, path: '/sync' },
        ];
      case 'volunteer':
        return [
          { label: t('nav.tasks'), icon: CheckSquare, path: '/dashboard' },
          { label: t('nav.active'), icon: Activity, path: '/active-tasks' },
          { label: t('nav.impact'), icon: Award, path: '/impact' },
          { label: t('nav.chat'), icon: MessageSquare, path: '/chats' },
        ];
      case 'ngo':
        return [
          { label: t('nav.fleet'), icon: Truck, path: '/dashboard' },
          { label: t('nav.triage'), icon: Filter, path: '/triage' },
          { label: t('nav.match'), icon: Zap, path: '/match' },
          { label: t('nav.bottlenecks'), icon: BarChart3, path: '/bottlenecks' },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-surface-container-high border-t border-outline-variant px-2 pb-safe pt-1 shadow-lg">
      <div className="max-w-md mx-auto flex items-center justify-around h-16">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex flex-col items-center justify-center w-16 h-full transition-all relative group",
              isActive ? "text-primary" : "text-on-surface-variant hover:text-on-surface"
            )}
          >
            <div className={cn(
              "w-12 h-8 flex items-center justify-center rounded-full transition-all group-hover:bg-surface-container-highest",
              "group-[.active]:bg-primary-container"
            )}>
              <item.icon className={cn(
                "w-6 h-6 transition-all",
                "group-[.active]:text-on-primary-container group-[.active]:scale-110"
              )} />
            </div>
            <span className={cn(
              "text-[11px] font-bold mt-1 tracking-tight transition-colors",
              "group-[.active]:text-primary"
            )}>
              {item.label}
            </span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
