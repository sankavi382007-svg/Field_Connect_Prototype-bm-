import React from 'react';
import { useFirebase } from '../contexts/FirebaseContext';
import { RefreshCw, CloudOff, CheckCircle } from 'lucide-react';

export default function SyncStatusBar() {
  const { isOnline, syncInProgress } = useFirebase();

  if (syncInProgress) {
    return (
      <div className="bg-primary text-white text-[11px] py-1 px-4 flex items-center justify-center gap-2 animate-pulse">
        <RefreshCw className="w-3 h-3 animate-spin" />
        <span className="font-bold uppercase tracking-wider">Syncing data to central database...</span>
      </div>
    );
  }

  if (!isOnline) {
    return (
      <div className="bg-error text-white text-[11px] py-1 px-4 flex items-center justify-center gap-2">
        <CloudOff className="w-3 h-3" />
        <span className="font-bold uppercase tracking-wider">Offline Mode - Changes will sync later</span>
      </div>
    );
  }

  return (
    <div className="bg-secondary text-white text-[11px] py-1 px-4 flex items-center justify-center gap-2">
      <CheckCircle className="w-3 h-3" />
      <span className="font-bold uppercase tracking-wider">All data synchronized</span>
    </div>
  );
}
