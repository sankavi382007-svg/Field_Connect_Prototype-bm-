import React, { useState, useEffect } from 'react';
import { useTranslation } from '../contexts/LanguageContext';

interface TranslatedTextProps {
  text: string;
  className?: string;
  as?: any;
}

export const TranslatedText: React.FC<TranslatedTextProps> = ({ 
  text, 
  className = '', 
  as: Component = 'span' 
}) => {
  const { language, translateDynamic } = useTranslation();
  const [displayText, setDisplayText] = useState(text);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (language === 'en') {
      setDisplayText(text);
      return;
    }

    const translate = async () => {
      setLoading(true);
      const translated = await translateDynamic(text);
      setDisplayText(translated);
      setLoading(false);
    };

    translate();
  }, [text, language, translateDynamic]);

  if (loading) {
    return (
      <Component className={`${className} animate-pulse bg-surface-container rounded px-2`}>
        ...
      </Component>
    );
  }

  return <Component className={className}>{displayText}</Component>;
};
