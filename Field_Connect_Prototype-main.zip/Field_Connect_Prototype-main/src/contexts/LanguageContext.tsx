import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, translations, languages } from '../lib/translations';
import { GoogleGenAI } from '@google/genai';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  translateDynamic: (text: string) => Promise<string>;
  isTranslating: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translationCache = new Map<string, string>();

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('app_language');
    return (saved as Language) || 'en';
  });
  const [isTranslating, setIsTranslating] = useState(false);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('app_language', lang);
  };

  const t = (key: string) => {
    return translations[language][key] || translations['en'][key] || key;
  };

  const translateDynamic = async (text: string): Promise<string> => {
    if (language === 'en' || !text || text.trim() === '') return text;
    
    const cacheKey = `${language}:${text}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey)!;
    }

    setIsTranslating(true);
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      
      if (!apiKey) {
        return text;
      }

      const ai = new GoogleGenAI({ apiKey });
      
      const targetLangName = languages.find(l => l.code === language)?.name || 'English';
      const prompt = `Translate to ${targetLangName}: "${text}"`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      
      const translated = response.text || text;
      translationCache.set(cacheKey, translated);
      
      return translated;
    } catch (error: any) {
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED')) {
        console.warn('Gemini quota reached. Falling back to original text.');
      } else {
        console.error('Translation error:', error);
      }
      return text;
    } finally {
      setIsTranslating(false);
    }
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, translateDynamic, isTranslating }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
