import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, onSnapshot, query, where, orderBy } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile } from '../types';
import { getOfflineDB } from '../lib/offline';

interface FirebaseContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isOnline: boolean;
  syncInProgress: boolean;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [syncInProgress, setSyncInProgress] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        setLoading(true);
        console.log('User authenticated, fetching profile for:', u.uid);
        
        // Timeout promise
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Profile fetch timed out')), 5000)
        );

        try {
          // Race getDoc against timeout
          const userDocPromise = getDoc(doc(db, 'users', u.uid));
          const userDoc = await Promise.race([userDocPromise, timeoutPromise]) as any;

          if (userDoc.exists()) {
            console.log('Profile found:', userDoc.data());
            setProfile(userDoc.data() as UserProfile);
          } else {
            console.warn('No profile document found for user:', u.uid);
            setProfile(null);
          }
        } catch (error) {
          console.error('Error fetching user profile:', error);
          setProfile(null);
        } finally {
          setLoading(false);
        }
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  // Offline Sync Logic
  useEffect(() => {
    if (isOnline && user && !syncInProgress) {
      const syncData = async () => {
        setSyncInProgress(true);
        try {
          const odb = await getOfflineDB();
          const pending = await odb.getAll('pending_sync');
          
          for (const item of pending) {
            try {
              if (item.type === 'create' || item.type === 'update') {
                await setDoc(doc(db, item.collection, item.data.id || item.id), item.data, { merge: true });
              } else if (item.type === 'delete') {
                // Delete logic if needed
              }
              await odb.delete('pending_sync', item.id);
            } catch (err) {
              console.error('Failed to sync item:', item.id, err);
            }
          }
        } finally {
          setSyncInProgress(false);
        }
      };

      syncData();
    }
  }, [isOnline, user, syncInProgress]);

  return (
    <FirebaseContext.Provider value={{ user, profile, loading, isOnline, syncInProgress }}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
