import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface FieldConnectDB extends DBSchema {
  pending_sync: {
    key: string;
    value: {
      id: string;
      collection: string;
      data: any;
      type: 'create' | 'update' | 'delete';
      createdAt: number;
    };
    indexes: { 'by-date': number };
  };
  cached_data: {
    key: string;
    value: {
      id: string;
      collection: string;
      data: any;
      updatedAt: number;
    };
    indexes: { 'by-collection': string };
  };
}

let dbPromise: Promise<IDBPDatabase<FieldConnectDB>>;

export function getOfflineDB() {
  if (!dbPromise) {
    dbPromise = openDB<FieldConnectDB>('field-connect-offline', 1, {
      upgrade(db) {
        const syncStore = db.createObjectStore('pending_sync', { keyPath: 'id' });
        syncStore.createIndex('by-date', 'createdAt');
        
        const cacheStore = db.createObjectStore('cached_data', { keyPath: 'id' });
        cacheStore.createIndex('by-collection', 'collection');
      },
    });
  }
  return dbPromise;
}

export async function addToSyncQueue(collection: string, data: any, type: 'create' | 'update' | 'delete' = 'create') {
  const db = await getOfflineDB();
  const syncItem = {
    id: `${collection}_${data.id || Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    collection,
    data,
    type,
    createdAt: Date.now(),
  };
  await db.add('pending_sync', syncItem);
  return syncItem.id;
}

export async function getSyncQueue() {
  const db = await getOfflineDB();
  return db.getAllFromIndex('pending_sync', 'by-date');
}

export async function removeFromSyncQueue(id: string) {
  const db = await getOfflineDB();
  await db.delete('pending_sync', id);
}
