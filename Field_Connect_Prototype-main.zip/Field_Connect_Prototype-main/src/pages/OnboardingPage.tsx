import React, { useState } from 'react';
import { useFirebase } from '../contexts/FirebaseContext';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, auth } from '../lib/firebase';
import { useNavigate } from 'react-router-dom';
import { UserRole } from '../types';
import { CheckCircle, MapPin, Building2, UserCircle2, Brain, Languages, ShieldCheck, Heart, Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';

export default function OnboardingPage() {
  const { profile, user } = useFirebase();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<any>({
    // Shared
    displayName: profile?.displayName || '',
    
    // Community Head
    assignedRegion: '',
    officialDesignation: '',
    languagePreference: 'English',

    // Volunteer
    skills: [] as string[],
    mindsetStatement: '',
    location: null as any,

    // NGO
    organizationName: '',
    registrationNumber: '',
    panDetails: '',
    officeAddress: '',
    officeBearers: [
      { name: '', contact: '', role: 'President' },
      { name: '', contact: '', role: 'Secretary' },
      { name: '', contact: '', role: 'Treasurer' }
    ]
  });

  if (!profile || !user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const updates = {
        ...formData,
        isOnboarded: true,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, 'users', user.uid), updates);
      window.location.href = '/dashboard';
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const captureLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setFormData({
          ...formData,
          location: {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          }
        });
      });
    }
  };

  const volunteerSkills = ['Vision AI', 'Logistics', 'Medical', 'Psychology', 'Construction', 'Digital Literacy', 'Agriculture'];

  return (
    <div className="min-h-screen bg-surface p-4 flex items-center justify-center">
      <div className="w-full max-w-2xl bg-surface-container rounded-[2.5rem] p-8 shadow-2xl border border-outline-variant space-y-8">
        <div className="text-center space-y-2">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-black italic tracking-tighter text-on-surface uppercase">Profile Setup</h1>
          <p className="text-on-surface-variant font-medium">Verify your credentials for the dimension of {profile.role?.replace('_', ' ')}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-widest text-on-surface-variant px-1">Full Name</label>
            <div className="relative group">
              <UserCircle2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant group-focus-within:text-primary transition-colors" />
              <input
                type="text"
                value={formData.displayName}
                onChange={(e) => setFormData({...formData, displayName: e.target.value})}
                className="w-full bg-surface-container-low border border-outline rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-medium"
                required
              />
            </div>
          </div>

          {profile.role === 'community_head' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Assigned Region</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                    <input
                      placeholder="Village/District"
                      className="w-full bg-surface-container-low border border-outline rounded-xl py-3 pl-12 pr-4 focus:ring-2 focus:ring-primary transition-all"
                      onChange={(e) => setFormData({...formData, assignedRegion: e.target.value})}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Designation</label>
                  <div className="relative">
                    <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                    <input
                      placeholder="e.g. Village Sarpanch"
                      className="w-full bg-surface-container-low border border-outline rounded-xl py-3 pl-12 pr-4 focus:ring-2 focus:ring-primary transition-all"
                      onChange={(e) => setFormData({...formData, officialDesignation: e.target.value})}
                      required
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Primary Language</label>
                <div className="relative">
                  <Languages className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                  <select
                    className="w-full bg-surface-container-low border border-outline rounded-xl py-3 pl-12 pr-4 focus:ring-2 focus:ring-primary transition-all appearance-none"
                    onChange={(e) => setFormData({...formData, languagePreference: e.target.value})}
                  >
                    <option>English</option>
                    <option>Hindi</option>
                    <option>Tamil</option>
                    <option>Telugu</option>
                    <option>Kannada</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {profile.role === 'volunteer' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Specialized Skills (Select Multiple)</label>
                <div className="flex flex-wrap gap-2">
                  {volunteerSkills.map(skill => (
                    <button
                      key={skill}
                      type="button"
                      onClick={() => {
                        const skills = formData.skills.includes(skill)
                          ? formData.skills.filter((s: string) => s !== skill)
                          : [...formData.skills, skill];
                        setFormData({...formData, skills});
                      }}
                      className={cn(
                        "px-4 py-2 rounded-full text-xs font-bold border transition-all",
                        formData.skills.includes(skill)
                          ? "bg-primary text-on-primary border-primary"
                          : "bg-surface-container-low text-on-surface-variant border-outline hover:border-primary"
                      )}
                    >
                      {skill}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Helping Mindset Statement</label>
                <textarea
                  placeholder="Why do you want to help?"
                  className="w-full h-24 bg-surface-container-low border border-outline rounded-xl p-4 focus:ring-2 focus:ring-primary transition-all"
                  onChange={(e) => setFormData({...formData, mindsetStatement: e.target.value})}
                  required
                />
              </div>

              <button
                type="button"
                onClick={captureLocation}
                className={cn(
                  "flex items-center justify-center gap-2 w-full py-4 rounded-xl font-bold transition-all border",
                  formData.location ? "bg-tertiary/10 text-tertiary border-tertiary" : "bg-primary/5 text-primary border-primary/20 hover:bg-primary/10"
                )}
              >
                <MapPin className="w-5 h-5" />
                {formData.location ? "Location Captured" : "Capture GPS Location"}
              </button>
            </div>
          )}

          {profile.role === 'ngo' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Organization Name</label>
                  <input
                    className="w-full bg-surface-container-low border border-outline rounded-xl py-3 px-4 focus:ring-2 focus:ring-primary transition-all"
                    onChange={(e) => setFormData({...formData, organizationName: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">DARPAN / Reg. ID</label>
                  <input
                    className="w-full bg-surface-container-low border border-outline rounded-xl py-3 px-4 focus:ring-2 focus:ring-primary transition-all"
                    onChange={(e) => setFormData({...formData, registrationNumber: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Office Address</label>
                <textarea
                  className="w-full h-20 bg-surface-container-low border border-outline rounded-xl p-4 focus:ring-2 focus:ring-primary transition-all"
                  onChange={(e) => setFormData({...formData, officeAddress: e.target.value})}
                  required
                />
              </div>

              <div className="space-y-4">
                 <label className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Office Bearers (Contact Info)</label>
                 {formData.officeBearers.map((bearer: any, idx: number) => (
                   <div key={idx} className="grid grid-cols-2 gap-2">
                     <input
                       placeholder={bearer.role}
                       className="bg-surface-container-low border border-outline rounded-xl py-2 px-3 text-sm focus:ring-1 focus:ring-primary"
                       onChange={(e) => {
                         const bearers = [...formData.officeBearers];
                         bearers[idx].name = e.target.value;
                         setFormData({...formData, officeBearers: bearers});
                       }}
                       required
                     />
                     <input
                       placeholder="Phone"
                       className="bg-surface-container-low border border-outline rounded-xl py-2 px-3 text-sm focus:ring-1 focus:ring-primary"
                       onChange={(e) => {
                         const bearers = [...formData.officeBearers];
                         bearers[idx].contact = e.target.value;
                         setFormData({...formData, officeBearers: bearers});
                       }}
                       required
                     />
                   </div>
                 ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary text-on-primary py-5 rounded-3xl font-black text-xl uppercase italic tracking-tighter shadow-lg shadow-primary/20 flex items-center justify-center gap-3 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
          >
            {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin" /> : (
              <>
                Finalize Verification <CheckCircle className="w-6 h-6" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
