import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useFirebase } from '../contexts/FirebaseContext';
import { useTranslation } from '../contexts/LanguageContext';
import { collection, query, orderBy, onSnapshot, addDoc, doc, getDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Message, Chat } from '../types';
import { Send, ArrowLeft, Info, Plus, Image as ImageIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';
import { TranslatedText } from '../components/TranslatedText';

export default function ChatRoom() {
  const { chatId } = useParams<{ chatId: string }>();
  const { user, profile } = useFirebase();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatInfo, setChatInfo] = useState<Chat | null>(null);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chatId) return;

    const fetchChat = async () => {
      const chatDoc = await getDoc(doc(db, 'chats', chatId));
      if (chatDoc.exists()) {
        setChatInfo({ id: chatDoc.id, ...chatDoc.data() } as Chat);
      }
    };
    fetchChat();

    const q = query(
      collection(db, 'chats', chatId, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message)));
      scrollToBottom();
    });

    return unsubscribe;
  }, [chatId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !chatId || !user) return;

    const text = inputText;
    setInputText('');

    try {
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        senderId: user.uid,
        text,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-surface-container-lowest h-full relative">
      <header className="bg-white border-b border-outline-variant px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-surface-container rounded-full">
            <ArrowLeft className="w-5 h-5 text-primary" />
          </button>
          <div>
             <h2 className="font-bold text-on-surface line-clamp-1">{t('nav.chat')}</h2>
             <span className="text-[10px] font-black text-secondary uppercase tracking-widest">{t('nav.active')}</span>
          </div>
        </div>
        <button className="w-10 h-10 flex items-center justify-center rounded-full bg-surface-container-high text-on-surface-variant">
          <Info className="w-5 h-5" />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {messages.map((msg, i) => {
          const isMe = msg.senderId === user?.uid;
          return (
            <div key={msg.id} className={cn("flex flex-col max-w-[85%] animate-in fade-in slide-in-from-bottom-2", isMe ? "self-end items-end" : "self-start items-start")}>
               {!isMe && (
                 <span className="text-[10px] font-bold text-primary mb-1 ml-2 uppercase opacity-60">Team Member</span>
               )}
               <div className={cn(
                 "p-3.5 rounded-2xl shadow-sm text-sm leading-relaxed",
                 isMe 
                  ? "bg-primary text-on-primary rounded-tr-none" 
                  : "bg-white border border-outline-variant text-on-surface rounded-tl-none"
               )}>
                 <TranslatedText text={msg.text} />
               </div>
               <span className="text-[9px] text-outline font-bold mt-1.5 uppercase px-2">
                 {format(msg.createdAt, 'HH:mm')}
               </span>
            </div>
          )
        })}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-outline-variant sticky bottom-0">
        <form onSubmit={sendMessage} className="flex items-center gap-3">
          <button type="button" className="w-10 h-10 flex items-center justify-center rounded-full bg-surface-container hover:bg-surface-variant text-on-surface-variant">
            <Plus className="w-5 h-5" />
          </button>
          <div className="flex-1 relative">
            <input 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full h-12 bg-surface-container-low border-none rounded-2xl px-4 text-sm focus:ring-2 focus:ring-primary focus:bg-white transition-all placeholder:text-outline" 
              placeholder="Type a coordination message..." 
              type="text"
            />
          </div>
          <button 
            type="submit"
            className="w-12 h-12 flex items-center justify-center rounded-2xl bg-primary text-on-primary shadow-lg active:scale-95 transition-transform"
          >
            <Send className="w-5 h-5 fill-current" />
          </button>
        </form>
      </div>
    </div>
  );
}
