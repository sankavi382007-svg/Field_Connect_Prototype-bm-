import React, { useState, useEffect } from 'react';
import { useFirebase } from '../contexts/FirebaseContext';
import { useTranslation } from '../contexts/LanguageContext';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  User, 
  Camera,
  Globe, 
  Brain, 
  CalendarCheck, 
  MapPin, 
  Award, 
  LogOut, 
  Trash2, 
  Plus, 
  Zap, 
  Info, 
  CheckCircle2, 
  Clock, 
  Building2, 
  FileText, 
  Users,
  Navigation
} from 'lucide-react';
import { cn } from '../lib/utils';
import { TranslatedText } from '../components/TranslatedText';
import { motion, AnimatePresence } from 'motion/react';

export default function ProfilePage() {
  const { profile, user, loading, isOnline } = useFirebase();
  const { t } = useTranslation();
  const [isSaving, setIsSaving] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [localFormData, setLocalFormData] = useState<any>(null);

  // Sync local changes when coming back online
  useEffect(() => {
    if (isOnline && localFormData && user) {
      const syncData = async () => {
        try {
          await updateDoc(doc(db, 'users', user.uid), {
            ...localFormData,
            updatedAt: serverTimestamp()
          });
          setLocalFormData(null);
          localStorage.removeItem(`pending_profile_update_${user.uid}`);
        } catch (err) {
          console.error("Sync error:", err);
        }
      };
      syncData();
    }
  }, [isOnline, localFormData, user]);

  // Load pending changes from localStorage on mount
  useEffect(() => {
    if (user) {
      const saved = localStorage.getItem(`pending_profile_update_${user.uid}`);
      if (saved) {
        setLocalFormData(JSON.parse(saved));
      }
    }
  }, [user]);

  if (loading) return (
    <div className="flex-1 flex items-center justify-center bg-surface">
      <div className="text-center space-y-4">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-on-surface-variant font-medium animate-pulse">Accessing field records...</p>
      </div>
    </div>
  );

  if (!profile) return null;

  const handleUpdateProfile = async (updates: any) => {
    if (!user) return;
    setIsSaving(true);
    
    // Optimistic UI/Offline support
    const newLocalData = { ...(localFormData || {}), ...updates };
    setLocalFormData(newLocalData);
    localStorage.setItem(`pending_profile_update_${user.uid}`, JSON.stringify(newLocalData));

    try {
      if (isOnline) {
        await updateDoc(doc(db, 'users', user.uid), {
          ...updates,
          updatedAt: serverTimestamp()
        });
        setLocalFormData(null);
        localStorage.removeItem(`pending_profile_update_${user.uid}`);
      }
      
      setShowToast(true);
      setTimeout(() => setShowToast(false), 3000);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setIsSaving(false);
    }
  };

  const captureLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        // In a real app, we'd reverse geocode here. For now, using coordinates as address.
        await handleUpdateProfile({
          location: {
            lat: latitude,
            lng: longitude,
            address: `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}`
          }
        });
      },
      (error) => {
        console.error("Error capturing location:", error);
        alert("Unable to retrieve your location. Please check browser permissions.");
      }
    );
  };

  const effectiveProfile = { ...profile, ...(localFormData || {}) };

  return (
    <div className="flex-1 p-4 max-w-4xl mx-auto space-y-8 pb-12 relative">
      {/* Toast Notification */}
      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-secondary text-on-secondary px-6 py-3 rounded-full shadow-2xl font-bold flex items-center gap-2 border border-white/20"
          >
            <CheckCircle2 className="w-5 h-5" />
            Profile Updated Successfully
          </motion.div>
        )}
      </AnimatePresence>

      <header className="flex justify-between items-start">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black text-on-surface">{t('profile.settings')}</h1>
            {effectiveProfile.isVerified ? (
              <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified
              </span>
            ) : (
              <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1 border border-amber-200">
                <Clock className="w-3.5 h-3.5" /> Pending Verification
              </span>
            )}
          </div>
          <p className="text-on-surface-variant font-medium italic opacity-70">UID: {profile.uid.slice(0, 8)}...{profile.uid.slice(-4)}</p>
        </div>
        <button 
          onClick={() => auth.signOut()}
          className="p-3 bg-error-container text-on-error-container rounded-2xl hover:brightness-95 active:scale-95 transition-all flex items-center gap-2 border border-error/10"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-bold text-xs uppercase tracking-tight">{t('profile.signOut')}</span>
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Core Info */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white border border-outline-variant rounded-3xl p-8 flex flex-col items-center justify-center space-y-6 shadow-sm overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-24 bg-primary/5" />
            <div className="relative group z-10">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-2xl relative">
                <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(profile.displayName)}&background=003e6f&color=fff&size=256`} className="w-full h-full object-cover" alt="User Avatar" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                  <Camera className="w-8 h-8 text-white" />
                </div>
              </div>
            </div>
            
            <div className="text-center z-10 w-full">
              <h2 className="text-2xl font-black text-on-surface tracking-tight leading-none mb-1">
                {profile.displayName}
              </h2>
              <span className="inline-block px-3 py-1 bg-surface-container rounded-lg text-[10px] font-black text-outline uppercase tracking-widest border border-outline-variant/30">
                {profile.role.replace('_', ' ')}
              </span>
            </div>

            <div className="w-full pt-6 border-t border-outline-variant space-y-4 z-10">
              {profile.role === 'volunteer' && (
                <div className="flex items-center justify-between p-4 bg-surface-container rounded-2xl border border-outline-variant/30">
                  <div className="flex items-center gap-3">
                    <CalendarCheck className={cn("w-6 h-6", effectiveProfile.status === 'active' ? "text-secondary" : "text-outline")} />
                    <div className="flex flex-col">
                      <span className="font-black text-xs uppercase text-on-surface leading-none">{effectiveProfile.status === 'active' ? 'Active' : 'Away'}</span>
                      <span className="text-[10px] text-outline font-bold uppercase tracking-tight">Status</span>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={effectiveProfile.status === 'active'} 
                      onChange={(e) => handleUpdateProfile({ status: e.target.checked ? 'active' : 'away' })}
                      className="sr-only peer" 
                    />
                    <div className="w-12 h-6 bg-outline-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
                  </label>
                </div>
              )}

              {profile.role === 'volunteer' && (
                <div className="bg-amber-50 p-4 rounded-2xl text-[10px] text-amber-800 font-bold leading-relaxed border border-amber-100 flex items-start gap-3 uppercase tracking-tight shadow-inner">
                  <Info className="w-4 h-4 shrink-0" />
                  When "Away", you won't be prioritized for smart task matching.
                </div>
              )}
              
              <div className="space-y-1 px-1">
                <label className="text-[10px] font-black text-outline uppercase tracking-widest flex items-center gap-1.5 ml-1">
                  <Globe className="w-3 h-3" /> Registered Email
                </label>
                <div className="bg-surface-container p-4 rounded-2xl text-xs font-bold text-on-surface-variant border border-outline-variant/20 break-all">
                  {profile.email}
                </div>
              </div>
            </div>
          </div>

          {!isOnline && (
            <div className="p-4 bg-error-container text-on-error-container rounded-3xl border border-error/20 flex items-center gap-3">
              <SyncIcon className="w-6 h-6 animate-spin" />
              <div className="flex flex-col">
                <span className="font-black text-xs uppercase leading-none">Offline Mode</span>
                <span className="text-[10px] font-bold opacity-80 mt-1 uppercase tracking-tighter">Changes will sync once online.</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Role-Specific Forms */}
        <div className="lg:col-span-8 space-y-6">
          {profile.role === 'community_head' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
               <div className="bg-white border border-outline-variant rounded-3xl p-6 md:p-8 space-y-8 shadow-sm">
                  <div className="flex items-center gap-3 pb-6 border-b border-outline-variant">
                    <div className="p-3 bg-primary/10 rounded-2xl">
                      <MapPin className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Administrative Profile</h3>
                      <p className="text-xs text-on-surface-variant font-bold uppercase opacity-60">Jurisdiction & Language</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Assigned Region</label>
                       <input 
                         placeholder="Enter Village/District name"
                         value={effectiveProfile.assignedRegion || ''}
                         onChange={(e) => handleUpdateProfile({ assignedRegion: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none"
                       />
                       <p className="text-[10px] text-outline px-1">Specify your operational area for mapping.</p>
                    </div>

                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Official Designation</label>
                       <input 
                         placeholder="e.g. Panchayat Head"
                         value={effectiveProfile.officialDesignation || ''}
                         onChange={(e) => handleUpdateProfile({ officialDesignation: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none"
                       />
                       <p className="text-[10px] text-outline px-1">Your formal title for verification.</p>
                    </div>

                    <div className="md:col-span-2 space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Primary Language Preference</label>
                       <select 
                         value={effectiveProfile.languagePreference || 'english'}
                         onChange={(e) => handleUpdateProfile({ languagePreference: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none appearance-none cursor-pointer"
                       >
                         <option value="english">English (Global Default)</option>
                         <option value="hindi">हिन्दी (Hindi)</option>
                         <option value="telugu">తెలుగు (Telugu)</option>
                         <option value="tamil">தமிழ் (Tamil)</option>
                         <option value="kannada">ಕನ್ನಡ (Kannada)</option>
                         <option value="bengali">বাংলা (Bengali)</option>
                       </select>
                       <div className="flex items-start gap-2 p-4 bg-primary/5 rounded-2xl border border-primary/10">
                          <Brain className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                          <p className="text-[10px] text-primary/80 font-bold uppercase leading-relaxed tracking-tight">
                            Optimizing Vision AI: Selecting your native language helps our AI model accurately OCR street signs and local document uploads in your region.
                          </p>
                       </div>
                    </div>
                  </div>
               </div>
            </div>
          )}

          {profile.role === 'volunteer' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
               <div className="bg-white border border-outline-variant rounded-3xl p-6 md:p-8 space-y-8 shadow-sm">
                  <div className="flex items-center justify-between pb-6 border-b border-outline-variant">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-secondary/10 rounded-2xl">
                        <Users className="w-6 h-6 text-secondary" />
                      </div>
                      <div>
                        <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Volunteer Matching Profile</h3>
                        <p className="text-xs text-on-surface-variant font-bold uppercase opacity-60">Skills & Proximity</p>
                      </div>
                    </div>
                    {/* Capture GPS Location Button */}
                    <button 
                      onClick={captureLocation}
                      className="p-3 bg-primary text-on-primary rounded-2xl hover:brightness-95 active:scale-95 transition-all flex items-center gap-2 shadow-lg shadow-primary/20"
                    >
                      <Navigation className="w-5 h-5" />
                      <span className="font-bold text-[10px] uppercase tracking-widest hidden md:inline">Sync GPS</span>
                    </button>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-3">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Specialized Skills</label>
                       <div className="flex flex-wrap gap-2">
                          {['Healthcare', 'Logistics', 'Teaching', 'Driving', 'Heavy Lifting', 'First Aid', 'Translation', 'Cooking'].map(skill => {
                            const isSelected = effectiveProfile.skills?.includes(skill);
                            return (
                              <button
                                key={skill}
                                onClick={() => {
                                  const current = effectiveProfile.skills || [];
                                  const updated = isSelected 
                                    ? current.filter(s => s !== skill)
                                    : [...current, skill];
                                  handleUpdateProfile({ skills: updated });
                                }}
                                className={cn(
                                  "px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-tight transition-all border",
                                  isSelected 
                                    ? "bg-primary text-on-primary border-primary shadow-md shadow-primary/20" 
                                    : "bg-surface-container text-on-surface-variant border-outline-variant/30 hover:bg-white"
                                )}
                              >
                                {skill}
                              </button>
                            );
                          })}
                       </div>
                    </div>

                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Helping Mindset Statement</label>
                       <textarea 
                         placeholder="Why do you want to serve your community?"
                         value={effectiveProfile.mindsetStatement || ''}
                         onChange={(e) => handleUpdateProfile({ mindsetStatement: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none h-32 resize-none"
                       />
                       <p className="text-[10px] text-outline px-1 uppercase font-bold tracking-tighter">Gemini uses this to gauge your motivation during crisis matching.</p>
                    </div>

                    {effectiveProfile.location && (
                      <div className="p-4 bg-tertiary-container text-on-tertiary-container rounded-2xl border border-tertiary/10 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <MapPin className="w-5 h-5 text-tertiary" />
                          <div className="flex flex-col">
                            <span className="font-black text-xs uppercase leading-none">Last Synced Location</span>
                            <span className="text-[10px] font-bold opacity-80 mt-1">{effectiveProfile.location.address}</span>
                          </div>
                        </div>
                        <CheckCircle2 className="w-5 h-5 text-tertiary opacity-40" />
                      </div>
                    )}
                  </div>
               </div>

               {/* Gamification: Badges Section */}
               <div className="bg-primary text-on-primary rounded-3xl p-8 shadow-xl relative overflow-hidden group">
                  <div className="relative z-10 space-y-6">
                     <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <Award className="w-10 h-10 text-secondary fill-current drop-shadow-lg" />
                          <div>
                            <h3 className="font-black text-2xl uppercase italic tracking-tighter leading-none">Impact Portfolio</h3>
                            <p className="text-[10px] font-bold uppercase text-white/60 tracking-widest mt-1">Volunteer Excellence</p>
                          </div>
                        </div>
                        <div className="text-right">
                           <div className="text-5xl font-black">{profile.impactPoints || 0}</div>
                           <div className="text-[10px] font-bold uppercase opacity-80 tracking-widest mt-1">Karma Points</div>
                        </div>
                     </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-white/20">
                        <div className="space-y-4">
                           <div className="text-[11px] font-black uppercase tracking-widest text-white/70">Recently Unlocked</div>
                           <div className="flex gap-4">
                              <div className="flex flex-col items-center gap-2 group/badge">
                                <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20 shadow-xl group-hover/badge:scale-110 transition-transform">
                                   <Zap className="w-7 h-7 text-secondary fill-current" />
                                </div>
                                <span className="text-[8px] font-black uppercase tracking-tighter">Fast Responder</span>
                              </div>
                              <div className="flex flex-col items-center gap-2 group/badge opacity-30 cursor-not-allowed">
                                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10">
                                   <Users className="w-7 h-7" />
                                </div>
                                <span className="text-[8px] font-black uppercase tracking-tighter">Mobilizer</span>
                              </div>
                           </div>
                        </div>
                        <div className="flex flex-col justify-end items-end gap-2">
                           <button className="px-6 py-2 bg-secondary text-primary rounded-xl font-black text-xs uppercase tracking-widest shadow-xl shadow-secondary/20 hover:scale-105 active:scale-95 transition-all">
                              Global Leaderboard
                           </button>
                        </div>
                     </div>
                  </div>
                  {/* Decorative blobs */}
                  <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-secondary rounded-full blur-3xl opacity-20 group-hover:scale-125 transition-transform duration-1000"></div>
                  <div className="absolute -left-12 -top-12 w-32 h-32 bg-white rounded-full blur-3xl opacity-5"></div>
               </div>
            </div>
          )}

          {profile.role === 'ngo' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
               <div className="bg-white border border-outline-variant rounded-3xl p-6 md:p-8 space-y-8 shadow-sm">
                  <div className="flex items-center gap-3 pb-6 border-b border-outline-variant">
                    <div className="p-3 bg-primary/10 rounded-2xl">
                      <Building2 className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Organization Credentials</h3>
                      <p className="text-xs text-on-surface-variant font-bold uppercase opacity-60">Verification & Registration</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Organization Name</label>
                       <input 
                         placeholder="Legal Registered Name"
                         value={effectiveProfile.organizationName || ''}
                         onChange={(e) => handleUpdateProfile({ organizationName: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none"
                       />
                    </div>

                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">DARPAN ID / Reg. No.</label>
                       <input 
                         placeholder="e.g. WB/2024/012345"
                         value={effectiveProfile.registrationNumber || ''}
                         onChange={(e) => handleUpdateProfile({ registrationNumber: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none"
                       />
                    </div>

                    <div className="space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">PAN Details</label>
                       <input 
                         placeholder="Corporate PAN Number"
                         value={effectiveProfile.panDetails || ''}
                         onChange={(e) => handleUpdateProfile({ panDetails: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none"
                       />
                    </div>

                    <div className="md:col-span-2 space-y-2">
                       <label className="text-[11px] font-black text-on-surface-variant uppercase tracking-widest ml-1">Registered Office Address</label>
                       <textarea 
                         placeholder="Full legal address including state and PIN"
                         value={effectiveProfile.officeAddress || ''}
                         onChange={(e) => handleUpdateProfile({ officeAddress: e.target.value })}
                         className="w-full bg-surface-container p-4 rounded-2xl text-sm font-bold border border-outline-variant focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none h-24 resize-none"
                       />
                    </div>
                  </div>
               </div>

               {/* Office Bearers Section */}
               <div className="bg-white border border-outline-variant rounded-3xl p-6 md:p-8 space-y-8 shadow-sm">
                  <div className="flex items-center gap-3 pb-6 border-b border-outline-variant">
                    <div className="p-3 bg-secondary/10 rounded-2xl">
                      <FileText className="w-6 h-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-black text-xl text-on-surface uppercase tracking-tight">Primary Office Bearers</h3>
                      <p className="text-xs text-on-surface-variant font-bold uppercase opacity-60">Accountability Core</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {(effectiveProfile.officeBearers || []).map((bearer: any, idx: number) => (
                      <div key={idx} className="p-6 bg-surface-container rounded-3xl border border-outline-variant/30 flex flex-col md:flex-row md:items-center justify-between gap-4 group">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1">
                          <div className="space-y-1">
                            <label className="text-[9px] font-black text-outline uppercase tracking-wider">Name</label>
                            <div className="text-sm font-black text-on-surface">{bearer.name}</div>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] font-black text-outline uppercase tracking-wider">Designation</label>
                            <div className="text-xs font-bold text-on-surface-variant uppercase tracking-tight">{bearer.role}</div>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] font-black text-outline uppercase tracking-wider">Contact</label>
                            <div className="text-xs font-bold text-on-surface-variant">{bearer.contact}</div>
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            const updated = effectiveProfile.officeBearers.filter((_: any, i: number) => i !== idx);
                            handleUpdateProfile({ officeBearers: updated });
                          }}
                          className="p-2 text-error hover:bg-error/10 rounded-xl transition-colors md:opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}

                    <div className="p-6 border-2 border-dashed border-outline-variant rounded-3xl bg-surface/30">
                       <h4 className="text-[10px] font-black text-outline uppercase tracking-[0.2em] mb-4">Add Key Member</h4>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <input 
                            placeholder="Full Name"
                            id="bearer-name"
                            className="bg-white p-3 rounded-xl border border-outline-variant text-[11px] font-bold outline-none focus:border-primary"
                          />
                          <input 
                            placeholder="Designation"
                            id="bearer-role"
                            className="bg-white p-3 rounded-xl border border-outline-variant text-[11px] font-bold outline-none focus:border-primary"
                          />
                          <input 
                            placeholder="Contact No."
                            id="bearer-contact"
                            className="bg-white p-3 rounded-xl border border-outline-variant text-[11px] font-bold outline-none focus:border-primary"
                          />
                       </div>
                       <button 
                        onClick={() => {
                          const n = (document.getElementById('bearer-name') as HTMLInputElement).value;
                          const r = (document.getElementById('bearer-role') as HTMLInputElement).value;
                          const c = (document.getElementById('bearer-contact') as HTMLInputElement).value;
                          if (n && r && c) {
                            const updated = [...(effectiveProfile.officeBearers || []), { name: n, role: r, contact: c }];
                            handleUpdateProfile({ officeBearers: updated });
                            (document.getElementById('bearer-name') as HTMLInputElement).value = '';
                            (document.getElementById('bearer-role') as HTMLInputElement).value = '';
                            (document.getElementById('bearer-contact') as HTMLInputElement).value = '';
                          }
                        }}
                        className="w-full mt-4 py-3 bg-secondary/10 text-secondary hover:bg-secondary/20 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all"
                       >
                         Append Member Records
                       </button>
                    </div>

                    <div className="bg-amber-50 p-4 rounded-2xl text-[10px] text-amber-800 font-bold leading-relaxed border border-amber-100 flex items-start gap-3 uppercase tracking-tight">
                      <Info className="w-4 h-4 shrink-0" />
                      NGO accountability guidelines require at least three primary office bearers listed for verification status.
                    </div>
                  </div>
               </div>
            </div>
          )}
        </div>
      </div>

      {/* Global Save Indicator for Mobile */}
      <div className="fixed bottom-24 right-4 z-40 md:hidden">
          <div className={cn(
            "p-4 rounded-2xl shadow-2xl transition-all duration-300 flex items-center gap-3",
            isSaving ? "bg-primary text-on-primary scale-110" : "bg-surface text-outline scale-90 opacity-20 pointer-events-none"
          )}>
            <SyncIcon className="w-6 h-6 animate-spin" />
            <span className="font-bold text-xs uppercase tracking-widest">Saving...</span>
          </div>
      </div>
    </div>
  );
}

function SyncIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  );
}
