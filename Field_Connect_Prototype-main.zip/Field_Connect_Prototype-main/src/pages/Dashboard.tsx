import React from 'react';
import { useFirebase } from '../contexts/FirebaseContext';
import CommunityHeadDashboard from '../components/dashboards/CommunityHeadDashboard';
import VolunteerDashboard from '../components/dashboards/VolunteerDashboard';
import NGODashboard from '../components/dashboards/NGODashboard';
import { Navigate } from 'react-router-dom';

export default function Dashboard() {
  const { profile, loading } = useFirebase();

  if (loading) return (
    <div className="flex-1 flex items-center justify-center bg-surface">
      <div className="text-center space-y-4">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-on-surface-variant font-medium animate-pulse">Syncing your field profile...</p>
      </div>
    </div>
  );

  if (!profile) {
    console.warn('Dashboard: No profile found, redirecting to onboarding.');
    return <Navigate to="/" replace />;
  }

  switch (profile.role) {
    case 'community_head':
      return <CommunityHeadDashboard />;
    case 'volunteer':
      return <VolunteerDashboard />;
    case 'ngo':
      return <NGODashboard />;
    default:
      return <div className="p-8 text-center text-error font-bold">Unknown user role: {profile.role}</div>;
  }
}
