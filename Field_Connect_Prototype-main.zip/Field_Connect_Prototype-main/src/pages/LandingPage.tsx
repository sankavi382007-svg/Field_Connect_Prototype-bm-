import React, { useState, useEffect } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Building2, HeartHandshake, School2, ArrowRight, Mail, Lock, User as UserIcon, Loader2 } from 'lucide-react';
import { UserRole } from '../types';
import { cn } from '../lib/utils';
import { useFirebase } from '../contexts/FirebaseContext';
import { useNavigate } from 'react-router-dom';

export default function LandingPage() {
  const { user } = useFirebase();
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | 'google'>('google');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateForm = () => {
    if (!email.includes('@')) return 'Please enter a valid email.';
    if (password.length < 6) return 'Password must be at least 6 characters.';
    if (authMode === 'signup' && !displayName.trim()) return 'Please enter your name.';
    return null;
  };

  const initializeProfile = async (user: any, role: UserRole, name?: string) => {
    const userRef = doc(db, 'users', user.uid);
    try {
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: user.uid,
          email: user.email,
          displayName: name || user.displayName || 'User',
          role: role,
          isOnboarded: false,
          createdAt: serverTimestamp(),
          status: 'active',
          badges: [],
          impactPoints: 0,
          skills: []
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const handleManualAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;
    
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      if (authMode === 'signup') {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(result.user, { displayName });
        await initializeProfile(result.user, selectedRole, displayName);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (!selectedRole) return;
    setIsLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      await initializeProfile(result.user, selectedRole);
    } catch (error: any) {
      console.error('Login failed:', error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRoleSelection = async (role: UserRole) => {
    if (user) {
      setIsLoading(true);
      try {
        await initializeProfile(user, role);
        // Refreshing profile might be handled by context, but we might need a small delay or navigation
        window.location.reload(); // Hard refresh to ensure profile is fetched
      } catch (err) {
        console.error('Role initialization failed:', err);
      } finally {
        setIsLoading(false);
      }
    } else {
      setSelectedRole(role);
    }
  };

  const roles = [
    {
      id: 'community_head' as UserRole,
      title: 'Community Head',
      desc: 'Identify local needs and manage neighborhood resources.',
      icon: <Building2 className="w-8 h-8" />,
      color: 'bg-primary-container text-on-primary-container'
    },
    {
      id: 'volunteer' as UserRole,
      title: 'Volunteer',
      desc: 'Join the task force. Receive real-time assignments and help out.',
      icon: <HeartHandshake className="w-8 h-8" />,
      color: 'bg-secondary-container text-on-secondary-container'
    },
    {
      id: 'ngo' as UserRole,
      title: 'NGO Representative',
      desc: 'Oversee large-scale operations and deploy global resources.',
      icon: <School2 className="w-8 h-8" />,
      color: 'bg-tertiary-container text-on-tertiary-container'
    }
  ];

  return (
    <div className="flex-1 flex flex-col p-6 max-w-4xl mx-auto py-12">
      <header className="mb-12">
        <h1 className="text-4xl font-black mb-4 tracking-tighter uppercase italic text-primary">Field Connect</h1>
        <p className="text-on-surface-variant text-lg leading-relaxed max-w-2xl">
          Empowering communities through real-time coordination. Field Connect bridges the gap between those in need and those who can help.
        </p>
      </header>

      {!selectedRole ? (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h2 className="text-2xl font-bold">Select your role to begin:</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {roles.map((role) => (
              <button
                key={role.id}
                onClick={() => handleRoleSelection(role.id)}
                className="group text-left p-8 rounded-3xl transition-all duration-300 border-2 border-transparent bg-surface-container-low hover:bg-white hover:shadow-xl hover:scale-105 active:scale-95"
              >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-6 shadow-md ${role.color}`}>
                  {role.icon}
                </div>
                <h3 className="text-2xl font-bold mb-2">{role.title}</h3>
                <p className="text-on-surface-variant text-sm mb-8 leading-relaxed">{role.desc}</p>
                <div className="flex items-center gap-2 text-primary font-bold group-hover:gap-4 transition-all">
                  <span>Register</span>
                  <ArrowRight className="w-5 h-5" />
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="max-w-md mx-auto w-full space-y-8 animate-in zoom-in-95 duration-300">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSelectedRole(null)}
              className="p-2 hover:bg-surface-container rounded-full"
            >
              <ArrowLeftIcon className="w-6 h-6" />
            </button>
            <div>
              <h2 className="text-2xl font-bold">Onboarding as {selectedRole.replace('_', ' ')}</h2>
              <p className="text-sm text-on-surface-variant">Step 2: Authenticate your credentials</p>
            </div>
          </div>

          <div className="bg-white border border-outline-variant rounded-3xl p-8 shadow-xl space-y-6">
            <div className="flex bg-surface-container p-1 rounded-xl">
              <button 
                onClick={() => setAuthMode('google')}
                className={cn("flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all", authMode === 'google' ? "bg-white shadow-sm" : "opacity-60")}
              >
                Google
              </button>
              <button 
                onClick={() => setAuthMode('signin')}
                className={cn("flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all", authMode === 'signin' ? "bg-white shadow-sm" : "opacity-60")}
              >
                Email
              </button>
              <button 
                onClick={() => setAuthMode('signup')}
                className={cn("flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all", authMode === 'signup' ? "bg-white shadow-sm" : "opacity-60")}
              >
                Sign Up
              </button>
            </div>

            {authMode === 'google' ? (
              <div className="space-y-6 flex flex-col items-center">
                <p className="text-center text-sm text-on-surface-variant px-4">
                  Quickly secure your account using your Google profile for verified field ID.
                </p>
                <button
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                  className="w-full bg-primary text-on-primary py-4 px-8 rounded-2xl font-bold text-lg shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <GoogleIcon className="w-6 h-6" />}
                  Continue with Google
                </button>
              </div>
            ) : (
              <form onSubmit={handleManualAuth} className="space-y-4">
                {authMode === 'signup' && (
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-outline uppercase ml-1">Full Name</label>
                    <div className="relative">
                      <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
                      <input 
                        type="text" 
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-surface-container rounded-xl text-sm border-none focus:ring-2 focus:ring-primary" 
                        placeholder="John Doe"
                      />
                    </div>
                  </div>
                )}
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-outline uppercase ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
                    <input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-surface-container rounded-xl text-sm border-none focus:ring-2 focus:ring-primary" 
                      placeholder="name@example.com"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-outline uppercase ml-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-surface-container rounded-xl text-sm border-none focus:ring-2 focus:ring-primary" 
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                {error && <p className="text-xs font-bold text-error bg-error-container/20 p-3 rounded-lg">{error}</p>}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-primary text-on-primary py-4 rounded-2xl font-bold text-sm uppercase tracking-widest shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (authMode === 'signup' ? 'Create Account' : 'Sign In')}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ArrowLeftIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>
    </svg>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}
